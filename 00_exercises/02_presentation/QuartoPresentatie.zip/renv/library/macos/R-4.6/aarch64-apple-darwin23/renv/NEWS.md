# renv 1.3.0

* renv now quotes the URL, ref, and commit of a git record when passing them
  to `git`, and rejects records whose values `git` could read as an option
  (for example, a ref of `--upload-pack=<command>`) or as a request to run a
  transport helper. Previously, a crafted lockfile record or `git::` remote
  could have these values run as shell commands. (#2389)

* Fixed an error when detecting the Posit Package Manager platform on an
  Enterprise Linux distribution whose `/etc/os-release` declares an empty
  `VERSION_ID`; renv now falls back to the untransformed repository URL.
  (#2386)

* A trailing YAML comment on the `engine:` field of a Quarto document's header
  (for example, `engine: knitr # comment`) no longer prevents renv from
  inferring that the document is bound to knitr. (#2386)

* `renv::restore(retry = TRUE)` (and the interactive retry prompt) now keeps
  the packages which installed successfully in the first pass when the restore
  is transactional. Previously, the transactional rollback of the first pass
  discarded those packages, but the retry only re-installed the packages which
  had failed, leaving the library incomplete. A transactional rollback is now
  also reported as such, rather than as a successful installation, and
  `renv::install()` no longer lists rolled-back packages among the packages
  which failed to install. (#2380)

* `renv::restore()` once again ignores lockfile records for packages built
  for a different operating system (for example, a Windows-only package in a
  lockfile restored on Linux), rather than reporting them as failed installs.
  With a transactional restore, such a failure previously rolled back the
  entire restore. (#2380)

* `renv::hydrate()` (and so `renv::init()`) now installs packages
  non-transactionally, so a package that cannot be installed no longer causes
  the other packages being hydrated to be rolled back. (#2380)

* On Windows, `renv::install()` and `renv::restore()` no longer let profiles
  named by `R_PROFILE` or `R_PROFILE_USER` be sourced by the `R CMD INSTALL`
  processes they launch. Before R 4.3.0, `R CMD` did not honor `--vanilla`
  for those processes, so a profile which reset `.libPaths()` (as callr's
  does, e.g. when renv is run under rcmdcheck) could hide already-installed
  dependencies from the installer, causing installs to fail with
  "dependency is not available". (#2380)

* On Windows, the output reported for a failed package installation now
  includes what `R CMD INSTALL` wrote to stderr, which is where it reports
  the reason for the failure (for example, "dependency 'x' is not available").
  Previously, only stdout was captured, so such failures were reported with
  no output at all. (#2385)

* `HEAD` requests made with the `wget` download method now work. The request
  omitted the URL, and relied on shell redirection to capture the response
  headers, which was ignored on Windows; the headers wget reports are also
  now parsed correctly. (#2385)

* `renv::install()` now records the commit (`RemoteSha`) that a package was
  installed from when using the `git::` remote pathway, so that
  `renv::snapshot()` pins that package to the installed commit, and
  `renv::restore()` retrieves that same commit rather than whatever the
  recorded ref points at when the project is restored (including when pak is
  enabled). Restoring a git package from a lockfile written by an older
  version of renv, which has no `RemoteSha`, likewise records the commit that
  was installed, so the next `renv::snapshot()` pins it; until then, the
  installed package is treated as satisfying the lockfile's record, rather
  than being reported as a change. If a git server refuses to serve a pinned
  commit directly, renv now fetches the recent history of the recorded ref
  instead (deepening it as needed), and checks out the commit from there. In
  addition, `renv::install()`, `renv::restore()`, `renv::hydrate()`,
  `renv::update()`, and `renv::record()` now clone a given commit at most
  once, rather than up to three times, and remove those clones once they
  complete. (#2378)

* With pak enabled, installing a package from a sub-directory of a git
  repository now reports that pak does not support this, rather than asking
  pak to install from the repository's root. (#2378)

* `renv::update()` now checks for updates to packages that renv installed
  from `git::` remotes; previously, these packages were skipped. For git
  packages, it also now resolves a ref to the commit that git itself would
  fetch, rather than to any ref whose name ends with it (e.g. `feature/main`
  for `main`), and reports refs that no longer exist as errors. Packages
  installed from an annotated tag by remotes are no longer reported as out
  of date, and git packages with no recorded commit are only reported as out
  of date if a newer version is available. (#2378)

* Version constraints declared in the project's `DESCRIPTION` file (for
  example, `Imports: dplyr (>= 1.1.0)`) are now honored by `renv::install()`
  and validated by `renv::snapshot()`. Previously, these constraints were
  only used when they pinned an exact version with `==`; other constraints
  were silently ignored, so an installed dependency could be older than
  the version the project declared it required. Versions pinned by the
  lockfile during `renv::restore()`, or requested explicitly via
  `pkg@version`, or declared in the project's `Remotes` field, are never
  overridden by these constraints; renv reports the unmet constraint
  instead. When renv retrieves packages one at a time (for example, in
  `renv::upgrade()`), it also now reports whenever it replaces a package
  version that didn't satisfy the constraints of other packages, rather
  than only when that package was explicitly requested. `!=` constraints
  are now parsed as well. (#2377)

* `renv::dependencies()` now follows Quarto's engine-binding rules when
  inferring dependencies for `.qmd` documents. Documents bound to the knitr
  engine, whether via R chunks, an explicit `engine: knitr` declaration, or
  `knitr:` options in the YAML header, infer a dependency on `rmarkdown`, and
  additionally on `reticulate` when they contain Python chunks. Documents
  bound to another engine (for example, `engine: jupyter`) no longer infer a
  dependency on `rmarkdown`. (#2174)

* `renv::restore()` now resolves the dependencies of a package installed from
  r-universe using the git commit recorded in the lockfile (via the `RemoteUrl`
  and `RemoteSha` fields) when the recorded version is no longer available
  from the repository. Previously, the dependencies of the latest version were
  used instead, which could cause packages to be installed in the wrong order
  or force other locked packages to be upgraded. (#2370)

* renv now falls back to its R implementations, with a warning, if its
  compiled extensions exist but cannot be loaded. For example, when a binary
  package accidentally ships a shared library built for a different
  architecture. (eddelbuettel/r2u#162)

* `renv::restore()` can now restore Bioconductor packages whose recorded
  version is no longer available from the Bioconductor repositories. This is
  most often seen with the devel branch of Bioconductor, which does not archive
  superseded package versions. In such cases, renv now retrieves the package
  sources from the git commit recorded in the lockfile (via the `git_url` and
  `git_last_commit` fields), and installs the package from those. (#2370)

* Staged package installations now use the project library root by default.
  This allows projects on network drives to retain cache junctions on Windows
  when their libraries and cache are stored locally. Installs into a different
  library stage within that library, and `RENV_PATHS_LIBRARY_STAGING` continues
  to override the staging location. (#2368)

* The large-file-count warning during `renv::dependencies()` now accounts
  for whether an `.renvignore` file already exists, and suggests modifying it
  instead of creating one. (#2193, @jkylearmstrong)

* When bootstrapping renv from GitHub, errors while extracting the commit SHA
  from the downloaded archive are now reported without aborting the bootstrap
  process. Installation is attempted without adding GitHub metadata.
  (#2366, @jkylearmstrong)

* `renv::update()` no longer tries to fork the R session when checking
  packages installed from non-CRAN remotes within Positron, whose R kernel
  forbids forking. Such checks now run sequentially there, as they already do
  on Windows. (#2364)

* `renv::dependencies()` no longer emits encoding warnings when checking R
  script headers containing non-ASCII text in a different encoding from the
  current locale. This also avoids failures when warnings are treated as
  errors. (#2362)

* Fixed an issue where renv computed the wrong Posit Package Manager binary
  URL on some Enterprise Linux distributions. CentOS Stream 9 and 10 were
  mapped to the non-existent `centos9` and `centos1` platforms rather than
  `rhel9` and `rhel10`, and Rocky Linux 10 and AlmaLinux 10 were mapped to
  `rhel1` rather than `rhel10`, causing package downloads to fail with 404
  errors. (#2354)

* Fixed an issue where renv would busy-wait, consuming an entire CPU core,
  while waiting to acquire a lock. The retry loop's backoff had become
  unreachable, so renv retried as fast as it could rather than at the intended
  0.2s interval. In addition, when the lock path was not writable at all (for
  example, under an OS sandbox denying writes outside the project), the loop
  had no terminating condition and renv would hang indefinitely -- silently,
  and uninterruptibly when reached via `renv/activate.R` during startup. renv
  now backs off between attempts, and reports an error (including the reason
  reported by the operating system) when the lock path cannot be written.
  (#2358)

* Fixed an issue where, with the `renv.install.allowArchivedPackages` option
  enabled, a package available only from a repository's archive would resolve
  to nothing at all. The archive was queried, but the result was then
  discarded: the lookup only ever returned the repository or crandb candidate.
  Archived candidates are now used when neither of those can supply the
  package. Records resolved this way also carry the URL of the repository's
  archive, so they can be downloaded in the same parallel batch as everything
  else, and they retain their repository even when `getOption("repos")` is
  unnamed. Their archived `DESCRIPTION` is read before dependency resolution,
  so strong dependencies are not omitted, and binary-only requests continue
  to reject these source-only candidates. (#2356)

* The available-package lookup now stops at the first source that can supply
  the package, rather than querying every source and discarding the extra
  answers. Repositories still take precedence over P3M, crandb, and the archive,
  so renv no longer makes fallback requests whose results it cannot use.
  (#2357)

* On Windows and macOS, the available-package lookup once again consults the
  P3M historical-binary database when configured repositories have no
  candidate. P3M binaries are preferred over crandb version hints and enabled
  repository archives, while source-only requests do not consult P3M. Missing
  records for newer R or platform versions are treated as an ordinary miss
  while the database catches up. (#2360)

* Fixed an issue where `renv::sysreqs()` (and the system requirement checks
  performed during install and restore) would only report the first system
  package required by an R package. When a package's `SystemRequirements`
  field declared multiple system libraries -- for example, `ragg` declares
  freetype2, libpng, libtiff, libjpeg, and libwebp -- only the first matching
  system dependency was reported. All matching dependencies are now reported.
  (#2352)

* Fixed an issue where, if one or more repositories could not be queried for
  available packages, the partial result would be cached and served for up to
  an hour -- renv would behave as though the failed repositories held no
  packages at all, without reporting why. Partial results are no longer
  cached, so failed repositories are re-queried (and failures re-reported)
  on subsequent calls. Similarly, failed archive queries (used when the
  `renv.install.allowArchivedPackages` option is enabled) are no longer
  cached, as the failure may be transient; such queries are still only
  attempted once per operation. (#2350)

* When the `renv.config.crandb.enabled` option is set, renv now prefers the
  record from the active repositories whenever those repositories can supply
  the package, rather than taking whichever of the two reports the newer
  version. crandb is not restricted to the active repositories, so it could
  name a version they don't carry -- for example, when they're pinned to a
  dated snapshot such as `https://p3m.dev/cran/2025-03-28`. renv now consults
  crandb only when the active repositories have no candidate at all, which is
  the case it was added to handle: finding a version compatible with an older
  version of R. (#2345)

* Fixed an issue where renv would warn that a package "was loaded before renv
  activated this project" when no such thing had happened. Projects using
  Bioconductor were affected on every startup, as renv loads `BiocManager`
  itself when resolving Bioconductor repositories. The check also mistook
  packages linked into the project library from the renv cache for packages
  loaded from outside the library paths. (#2344)

* `renv::install()` and `renv::restore()` no longer build a package from source
  when a binary of the requested version is available, in cases where the
  active repositories are pinned to a dated snapshot (for example, a Posit
  Package Manager URL like `https://p3m.dev/cran/2025-03-28`) and the
  `renv.config.crandb.enabled` option is set. renv consulted crandb to find the
  newest version of the package, but because crandb is not restricted to the
  configured repositories, it could report a version those repositories don't
  provide -- and renv then fell back to installing from source. (#2345)


# renv 1.2.4

* `renv::install()` and `renv::restore()` with pak enabled can now handle
  packages hosted on a self-hosted GitLab instance. renv previously handed
  pak remotes of the form `gitlab@<host>::<group>/<project>`, which pak was
  unable to parse; renv now translates these into pkgdepends' own syntax,
  `gitlab::https://<host>/<group>/<project>`. GitLab sub-directories are
  likewise translated to pkgdepends' `/-/<subdir>` syntax. (#2180)

* When a package fails to download, renv now reports the reason for the
  failure, rather than a generic "failed to download" message. For example,
  when the download destination within the renv root is not writable (as can
  happen with a misconfigured shared cache), the error now says so directly.
  (#2340)

* Failed package downloads are now reported quietly when a later retrieval
  candidate succeeds -- for example, when a binary package fails to download,
  but the source fallback succeeds. If all candidates fail, the download
  output is still emitted, and download errors are no longer reported twice.
  (#1727)

* `renv::use()` with pak enabled now honours the requested remotes, rather than
  installing the latest version of each package from the active repositories.
  Previously, a call like `renv::use("generics@0.1.3")` would install the
  current CRAN version of generics. `renv::rebuild()` and `renv::repair()` were
  affected in the same way. (#2341)

* `renv::remove()` gains a `prompt` argument, and now asks for confirmation
  before removing packages from a library other than the project library --
  for example, when called without an activated renv project, where the
  target library would be the user library. (#2331)

* Removing a package record from the lockfile by setting it to `NULL`, e.g.
  with `renv::record(list(dplyr = NULL))`, is now documented. (#2331)

* Package projects can now request that the package itself be included in the
  lockfile, by setting `Config/renv/snapshot/include-self: TRUE` in the package
  `DESCRIPTION` file. This can be useful when deploying a Shiny application
  that is developed as part of a package. See `?renv::snapshot` for more
  details. (#2285)

* `renv::dependencies()` now detects packages referenced via
  `rlang::check_installed()` and `rlang::is_installed()`. (#1936)

* `renv::dependencies()` now infers the optional packages required by certain
  testthat functions; for example, `skip_if_offline()` implies a dependency on
  curl, and `snapshot_review()` implies dependencies on shiny and diffviewer.
  In addition, usage of the Junit reporter is now also detected in calls to
  `test_check()` and `test_local()`. (#1936)

* `renv::dependencies()` now detects a dependency on the ragg package when the
  `ragg_png` graphics device is requested via knitr chunk options set in a
  document's YAML header. Previously, only calls of the form
  `knitr::opts_chunk$set(dev = "ragg_png")` in code chunks were detected.
  (#2311)

* `renv::install()` with pak enabled no longer upgrades already-installed
  dependencies that are only pulled in transitively -- most visibly recommended
  packages such as `cluster` or `Matrix`, which previously could be rebuilt when
  installing an unrelated package. renv now passes `upgrade = FALSE` to pak,
  matching renv's own installer, while still forcing a (re)install of the
  packages you explicitly request. (#2329)

* Internal DESCRIPTION reads that request a package by name now error when that
  package is not installed, rather than silently falling back to the DESCRIPTION
  in the current working directory. (#2327)

* renv now guards against corrupted cache entries that contain the wrong
  package. Before installing a package from the cache, renv verifies that the
  cache entry's `DESCRIPTION` reports the expected package name; if it does not
  (for example, due to a concurrent write race on a shared cache), renv ignores
  the entry and reinstalls the package instead of installing the wrong one.
  `renv::diagnostics()` also reports any such cache entries. (#2322)

* renv's file locks now record the host and process that own them. A lock held
  by a process that is still alive on the same machine is no longer treated as
  orphaned, even if its timestamp is stale (for example, when a large package
  copy onto a shared cache takes longer than the lock timeout and the watchdog
  is not refreshing the lock). This reduces the chance of a lock being stolen
  from a live process, which could otherwise corrupt a shared cache. (#2322)

* `renv::rehash()` now reminds you to run `renv::repair()` when it moves
  packages within the active cache, since project libraries that still link to
  a package's previous cache location are left with broken links. The
  function's documentation has also been corrected: it no longer claims that
  links to the old locations are retained.

* When `renv::snapshot()` aborts due to a pre-flight validation failure, the
  error now includes a summary of the problems that were detected (for example,
  the missing packages or unsatisfied dependencies). Previously these details
  were only printed to the console, so they could be lost when that output was
  not visible (such as when stdout is captured).

* The new `lockfile()` function provides a generic entry point for creating an
  renv lockfile from a variety of sources. For example,
  `lockfile(from = "manifest.json")` converts a Posit Connect `manifest.json`
  file into a lockfile. Supply `to` to also write the result to disk, as in
  `lockfile(from = "manifest.json", to = "renv.lock")`. The set of supported
  sources may be expanded in future releases. (#2245)

* `renv::snapshot()` gains a `description` parameter, which converts a package
  `DESCRIPTION` (provided either as a named list of fields, or as a path to a
  package directory or `DESCRIPTION` file) into a single lockfile record,
  without requiring the package to be installed. This allows tools like
  rsconnect to perform manifest-to-lockfile conversion using exported renv
  APIs. (#2250)

* When resolving the dependencies of a pinned package version that is absent
  from the configured repositories' `PACKAGES` metadata and cannot be found via
  crandb (for example, when offline, when using an internal mirror that cannot
  reach `crandb.r-pkg.org`, or for non-CRAN packages), renv now downloads the
  archived source tarball for that version and reads its `DESCRIPTION` directly.
  This is authoritative wherever the package itself is reachable, and the
  downloaded tarball is reused by the subsequent retrieve step. As a last
  resort, if the archived tarball also cannot be read, renv falls back to the
  latest version's dependencies and warns, since those dependencies may differ
  from the pinned version's and could lead to an incorrect install order.
  (#2315)

* Fixed a regression introduced in renv 1.2.0 where installing a package from
  the cellar (via `install()` or `use()`) failed to install that package's
  dependencies. The graph-based installer resolved cellar packages from
  metadata that omitted their `Depends` / `Imports` / `LinkingTo` fields; renv
  now reads the package's `DESCRIPTION` from the cellar archive so that its
  dependencies are discovered and installed. (#2313)

* renv now infers some "implied" dependencies that cannot be discovered via
  static analysis because they are loaded indirectly at runtime by another
  package. For example, dplyr lazily loads dbplyr when working with a database
  backend, so dbplyr is now recorded when a project uses both dplyr and a DBI
  backend (e.g. RSQLite, RPostgres, duckdb). The rules are configurable via the
  `renv.dependencies.implied` R option; set it to an empty list to disable this
  inference entirely. (#2308)

* `renv::restore()` gains a `retry` argument, controlling whether packages
  that fail to install successfully are retried with their latest available
  versions. This recovery was previously only offered via an interactive
  prompt; `retry = TRUE` now enables it without prompting (useful in
  non-interactive sessions such as CI), while `retry = FALSE` disables it
  entirely. (#1893)

* renv no longer treats the mere presence of a `biocViews` field in a
  package's `DESCRIPTION` as proof that the package came from Bioconductor.
  Some CRAN packages declare `biocViews`, and Posit Package Manager can serve
  Bioconductor packages from a CRAN-like "R repository"; in both cases renv
  now uses the `Repository` field to decide where a package was obtained, so
  such packages are recorded as repository packages and restored from the
  repository they came from. Genuine Bioconductor packages are still recognized
  by their `Repository` stamp, including binaries served via r-universe
  (stamped with a `https://bioc-*.r-universe.dev` URL); and when a package has
  no `Repository` stamp at all (as for bioconductor.org binaries, or very old
  or source-installed packages), renv trusts the `biocViews` field. (#2128)

* A new project setting, `settings$bioconductor.enabled()`, can be set to
  `FALSE` to opt a project out of Bioconductor entirely. When disabled, renv
  will not infer a Bioconductor source, activate Bioconductor repositories, or
  write a Bioconductor entry into the lockfile. (#2128)

* renv's internal DCF and properties readers now match their (ASCII)
  regular expressions with `useBytes = TRUE`. This avoids forcing PCRE
  into UTF mode, which could fail with "this version of PCRE is compiled
  without UTF support" -- in some environments preventing renv from even
  loading -- when R is linked against a PCRE library lacking UTF support
  or left in a state where it believes UTF is unsupported.

* `renv::install(<package>, type = "source")` once again installs from
  source when a binary Posit Package Manager (PPM) repository is
  configured. Previously, the dependency graph was resolved against the
  un-transformed (binary) repository URL, so a binary package could be
  installed even though source was requested. (#2303)

* The presence of an `rsconnect/` folder in a project is now treated as a
  development dependency on the `rsconnect` package, rather than a runtime
  dependency. This means `rsconnect` will no longer be automatically
  recorded by `renv::snapshot()` unless the project actually uses it at
  run time (or `settings$snapshot.dev(TRUE)` is set). (#2290)

* `renv::install()` no longer treats a package as already installed when
  its namespace is loaded from a path that is no longer on `.libPaths()`
  (e.g. when a global `~/.Rprofile` loads the package before renv
  activates). Previously, `install()` would silently skip these packages
  and `snapshot()` could not record them, leaving the project stuck.
  (#2300)

* On project load, renv now warns when one or more package namespaces
  have already been loaded from a path outside the active library
  paths. Such packages are not managed by renv and can cause
  `renv::status()` and `renv::snapshot()` to report inconsistencies.
  The check can be disabled via the `namespaces.check` config option
  (or the `RENV_CONFIG_NAMESPACES_CHECK` environment variable). (#2300)


# renv 1.2.3

* `renv::record()` now enriches each resolved record with the same
  DESCRIPTION-derived fields that `renv::snapshot()` writes (e.g.
  `Depends`, `Imports`, `Suggests`, `LinkingTo`, `License`), instead of
  producing a minimal record with only `Package`, `Version`, `Source`,
  and `Repository`. The metadata is fetched from the active package
  repositories (and crandb, when enabled, for CRAN packages) without
  reading the local library. Set `enrich = FALSE` to opt out and keep
  the previous minimal-record behavior. The `Hash` field is not computed
  for enriched records. Enriched records also store `Repository` as the
  named form (e.g. `CRAN`) that `renv::snapshot()` writes, rather than
  the contrib URL returned by `available.packages()`, so `renv::status()`
  no longer reports a spurious repository mismatch after a version-pinned
  `record()` call. (#2294)

* `renv::vulns()` now returns one record per requested package, with a
  `vulns` field that is an empty list when the package has no known
  vulnerabilities. Previously the `vulns` field was only present for
  vulnerable packages. (#2292)

* Fixed a regression where `renv::restore()` and `renv::install()` would
  re-download packages that were already installed in the user or site
  library, instead of reusing the existing installation. (#2288)

* Fixed an issue where `renv::snapshot()` would fail to install missing
  packages when `pak` was enabled and the user selected the "Install the
  packages, then snapshot" option at the prompt. `renv::install()` now
  forwards its `include` and `exclude` arguments to the pak backend, so
  `install(include = missing)` reliably installs the requested packages
  rather than falling through to a no-op project update. (#2281)

* Fixed an issue where `renv::init()` did not use pak to install missing
  dependencies, even when `pak.enabled = TRUE`. The install path used
  during init now delegates to pak when it is enabled. (#2282)

* Fixed an issue where `renv::hydrate()` could leak the raw pak return
  value into its `missing` field on the pak install path, instead of
  preserving the documented `NULL`-on-success contract.

* Fixed an issue where `renv::restore(clean = TRUE)` did not remove
  unused packages when `RENV_CONFIG_PAK_ENABLED=TRUE` (or
  `config$pak.enabled()` was otherwise set). The pak code path now honors
  `clean = TRUE` and drops packages from the project library that are not
  recorded in the lockfile, before delegating installs to pak. (#2280)

* New `install.keep.source` configuration option controls whether renv
  invokes `R CMD INSTALL` with `--with-keep.source`. Defaults to `TRUE`,
  matching existing behaviour; set to `FALSE` to install with
  `--without-keep.source`, which can significantly reduce the serialized
  size of functions defined by installed packages. (#1713)

* Fixed an issue where `renv::install()` could misreport packages as
  "built from source" when they were actually pre-built binaries
  served from a Posit Package Manager "binary" repository. The graph
  installer now classifies packages by inspecting the downloaded
  archive, rather than trusting the `type` passed to
  `available.packages()`.

* Fixed an issue where `renv::restore()` and `renv::install()` could resolve
  dependency constraints against the wrong version's `DESCRIPTION`. When a
  lockfile-pinned version was not available from the configured repositories
  (e.g. only the latest version is indexed, as on
  `packagemanager.posit.co/cran/latest`), the graph resolver substituted the
  latest version's `Depends`/`Imports`/`LinkingTo` fields in place of the
  pinned version's, which could force spurious upgrades of unrelated
  dependencies. The resolver now consults crandb for the pinned version's
  actual requirements before falling back to the latest entry. (#2278)

* Fixed an issue where setting `options(pkgType = "both")` on Linux could
  cause `renv::restore()` to extract a source tarball into the library as
  if it were a pre-built binary, skipping `R CMD INSTALL` and producing
  "has no 'package.rds' in Meta/" load-test failures. (#2275)

# renv 1.2.2

* Fixed an issue where `renv::install()` failed with named remotes in
  `DESCRIPTION` (e.g. `skeleton=kevinushey/skeleton`). The lazy remote
  resolution was not fully unwrapped, causing "object of type 'closure'
  is not subsettable" errors during dependency graph resolution. (#2272)

* Fixed an issue where binary packages could be installed before their
  dependencies during `renv::restore()`, causing load-test failures.
  Binary and source packages now participate in the same dependency-ordered
  installation. (#2268)


# renv 1.2.1

* `RENV_PATHS_LOCKFILE` now resolves relative paths against the project
  directory rather than the working directory. Previously, the effective
  lockfile path could change as the working directory changed within an R
  session. (#2238)

* `renv::install()` no longer upgrades transitive dependencies when the
  installed version already satisfies all dependency requirements. Previously,
  transitive dependencies were always upgraded to the latest available version,
  even when the existing library version was compatible. (#2232)

* Fixed an issue where `renv::update()` and `renv::install()` did not handle
  `RemoteSubdir` correctly for Bitbucket and GitLab packages. The subdirectory
  was not passed through during remote resolution, causing DESCRIPTION lookups
  to fail for packages that live in a repository subdirectory. (#2229)

* Fixed an issue where repository URLs from the lockfile could have
  `/src/contrib` appended twice, producing download URLs like
  `.../src/contrib/src/contrib/PACKAGES`.

* Fixed an issue where `renv::install(..., type = "binary")` was not
  respected during dependency graph resolution, causing renv to resolve
  source-only versions even when binaries were requested. (#2264, #2266)

* Fixed an infinite recursion in the JSON writer when encountering
  `numeric_version` objects.

* Packages installed from local sources can now fall back to repository
  sources when the local source is no longer available.

* `renv::install()` and `renv::restore()` now display progress when
  installing binary packages.

* `renv::use(repos = NULL)` now correctly resolves and installs transitive
  dependencies from the cache. Previously, only explicitly requested packages
  were installed. (#2254)

* The slow-dependency-discovery message during `renv::snapshot()` now accounts
  for whether an `.renvignore` file already exists, and adjusts the suggested
  action accordingly. (#2193, #2261)

* Fixed an error during `restore()` when a package from a custom repository
  could not be found in available packages, and the lockfile used the v2
  format. (#2263)

* The new `lockfile.sanitize` project setting controls whether renv strips
  embedded credentials from repository URLs when writing the lockfile. Set
  to `FALSE` to preserve credentials in the lockfile. See `?renv::settings`
  for more details. (#2262)

* Fixed an error when calling `renv::use()` multiple times in a single
  session. (#2248)

* Fixed an issue where GitLab packages with an empty `RemoteSubdir` field
  caused restore and install failures. (#2249)

* Fixed an error in the install report when a package record had no version,
  e.g. when a dependency could not be found in any configured repository.
  (#2251)

* Fixed an issue where `renv_record_source()` returned `"unknown"` for
  lockfile records that had a `Repository` field but no `Source` field.

* Fixed an issue where `renv::checkout()` could produce a broken `activate.R`
  script (e.g. `object '..md5..' not found` on session restart) when upgrading
  `renv` itself during checkout. (#2257)

* Fixed an issue where `renv::restore(packages = ...)` did not install
  transitive dependencies of the requested packages. (#2259)


# renv 1.2.0

* `renv::install()` and `renv::restore()` now download and install packages
  in parallel. Package downloads are batched into a single `curl --parallel`
  invocation, and source packages are compiled concurrently (up to
  `install.jobs` workers, default 4) using ready-queue scheduling that
  launches each package as soon as its dependencies finish. Binary packages
  are installed up front as they require no build-time ordering.

  Requires R >= 4.0 for full parallelism; older versions fall back to
  sequential installation.

* PPM is now enabled by default on arm64 Linux, as Posit Package Manager
  now serves binaries for that platform. (#2241)

* New function `renv::plan()` resolves the packages required by a project
  and generates a lockfile, without installing any packages. This can be
  used to preview what `renv::restore()` would install. Similarly,
  `renv::checkout()` with `actions = "snapshot"` now writes the resolved
  lockfile directly from repository metadata, rather than requiring
  packages to be installed first. Both functions accept a `dependencies`
  parameter (defaulting to `"strong"`) to control which dependency types
  are included in the recursive dependency tree.

* `renv::restore()` now consults the per-package `Repository` URL recorded
  in the lockfile when resolving and downloading packages. Previously, only
  the global repository list was used. The new `strict` parameter controls
  whether packages with a URL-valued `Repository` field must be retrieved
  from that exact repository (`strict = TRUE`) or merely prefer it
  (`strict = FALSE`, the default).

* Bootstrap failures during `.Rprofile` processing now emit a warning
  instead of an error.

* `renv::embed()` now warns when required packages are not found in the
  resolved lockfile. Previously, dependencies missing from the project
  lockfile were silently omitted from the generated `renv::use()` call.
  (#2178)

* `renv::embed()` gains support for `lockfile = NA`, which resolves
  package versions from the active package repositories rather than
  from installed packages or a lockfile. (#2178)

* `renv::dependencies()` now detects packages referenced via
  `system.file(..., package = "pkg")` calls. (#2236)

* The `renv.bioconductor.version` option is now respected as a global
  override during `renv::restore()` and `renv::load()`. Previously, the
  Bioconductor version recorded in the lockfile would take precedence,
  preventing users from overriding the Bioconductor version when needed.
  (#2218)

* renv now strips embedded credentials from repository URLs when writing
  the lockfile. URLs of the form `https://user:token@host/path` are
  sanitized to `https://host/path`, preventing accidental credential
  leakage when sharing `renv.lock` files. (#2191)

* The renv watchdog is now automatically disabled in child processes
  launched by parallel frameworks (e.g. `future::multisession`,
  `parallel::makePSOCKcluster()`, `callr`). (#2223)

* `renv::use(repos = NULL)` now uses a cache-only install path, ensuring
  packages are only installed from the renv cache and no external sources
  (repositories, GitHub, etc.) are queried. Previously, `restore()` and
  `install()` could still reach external sources through internal fallback
  logic.

* `renv::init(bioconductor = "devel")` now resolves symbolic Bioconductor
  version names (e.g. `"devel"`, `"release"`) to their numeric equivalents
  before writing to the lockfile. Previously, the literal string `"devel"`
  was written, causing `renv::restore()` to fail. (#2170)

* renv gains the configuration option `renv.config.crandb.enabled`. When
  enabled, renv will query the [crandb](https://github.com/r-hub/crandb)
  service to find the newest version of a package compatible with the current
  version of R. This can be useful when using an older version of R, where
  the latest version of a package on CRAN requires a newer R version.
  (#1735)

# renv 1.1.8

* Update to conform with changes to the R API.


# renv 1.1.7

* Fixed an issue where `.renvignore` files were not read when the project root
  was the filesystem root `/`. (#2203)

* Fixed an issue where `renv` would incorrectly warn about the version of
  `renv` being used on project load. (#2207)

* The renv version mismatch warning is now suppressed during bootstrap when
  `RENV_CONFIG_STARTUP_QUIET=TRUE` or `RENV_CONFIG_SYNCHRONIZED_CHECK=FALSE`
  is set. (#2214)

* Fixed an issue where `RENV_CONFIG_REPOS_OVERRIDE` with multiple named
  repositories (e.g., `NAME1=URL1;NAME2=URL2`) was not properly decoded by
  the configuration system, causing functions like `renv::install()` and
  `renv::restore()` to not use the specified repositories. (#2209)


# renv 1.1.6

* A new setting, `snapshot.dev`, has been added to control whether development
  dependencies are included by default when calling `renv::snapshot()` or
  `renv::status()`. This setting defaults to `FALSE`. (#2190)

* `RENV_CONFIG_REPOS_OVERRIDE` now supports multiple named repositories using
  the syntax `NAME1=URL1;NAME2=URL2`. Single repository URLs continue to be
  supported.

* Fixed an issue where `renv::sysreqs()` could fail on operating systems
  which don't declare a VERSION_ID in `/etc/os-release`. (#2197)

* `renv::dependencies()` now detects packages used in e.g.
  `data(<dataset>, package = <package>)`. (#2181)

* Fixed an issue where cache callbacks (e.g. those run by setting
  `RENV_CACHE_USER` and `RENV_CACHE_MODE`, or via the `renv.cache.callback`
  option) were not run after `renv::hydrate()`. (#2179)

* `renv::embed()` now errs if one or more of the package dependencies to
  be included within a file are not available. (#2178)

* `renv` gains the function `renv::vulns()`, which can be used to query
  vulnerability information from a Posit Package Manager instance.
  This information can be queried either for a specific set of packages,
  or for all packages defined in a lockfile.

* `renv` now also supports `RENV_LOCKFILE_VERSION = 1` as an alternate
  way to request the older, compact lockfiles. (#2175)

* The version check in `renv::status()` can now be disabled by setting
  `options(renv.status.check_version = FALSE)`. (#2167)

* Fixed an issue where the package manager URL was computed incorrectly
  with RHEL 10.

* `renv` now prints the version numbers of the packages it downloads during
  install and restore. (#1925)

* The `renv` configuration option `bioconductor.init` can now be used to
  control the default argument passed for the `bioconductor` parameter in
  calls to `renv::init()`. (#2128)

* `renv` now supports bootstrapping itself from the global package
  cache. (#1799)

* `renv` now prefers appending, rather than prepending, Bioconductor
  repositories to the current set of repositories when installing
  packages. This implies that if you're using a repository that also
  provides Bioconductor packages, this repository will be preferred
  as opposed to the "default" Bioconductor repositories. (#2128)

* `renv::restore()` now ignores the `Repository` field on lockfile entries
  when the `repos.override` configuration option is set. (#2127)

* `renv::restore()` now transforms binary repository URLs appropriately,
  for installed packages which were recorded as installed from an
  alternate binary repository URL. (#2127)


# renv 1.1.5

* Fixed an issue where `renv::dependencies()` could fail for chunks which
  had a `label` which was not a length-one character vector. (#2144)

* Fixed an issue where `file.rename()` could fail when unpacking a
  package during installation in certain Windows environments. (#2156)

* `renv`'s dependency discovery now supports usages of `base::use()`. (#2130)

* Fixed an issue where `renv` could fail to parse remote references
  containing an `@` character. (#2135)

* Fixed an issue where `renv::sysreqs(distro = <...>)` could fail when
  passed an alternate distribution without a version specifier. (#2105)

* Fixed an issue where multimode R documents containing chunk headers
  which did not parse to an R list could cause dependency inference
  to fail. (#2110)


# renv 1.1.4

* Fixed an issue where `renv` could erroneously record packages installed
  from Posit Package Manager snapshots as being installed from CRAN. (#2104)

* `renv` now only checks for archived packages during installation when
  `options(renv.install.allowArchivedPackages = TRUE)` is set. This fixes
  an issue where `renv` could erroneously discover that Rcpp 1.3 was
  available when using the Posit Package Manager repository.

* Fixed an issue where `renv::dependencies()` could fail with an
  unhelpful error message if the scanned document contained a
  YAML header whose contents was not a map. (#2117)


# renv 1.1.3

* Fixed an issue where `renv::hydrate()` could fail to install packages
  discovered in the user library during `renv::init()`. (#2109)

* `renv::update()` now only updates the packages installed in the project
  library by default. `renv::update(all = TRUE)` can be used to also
  check if packages installed in the default library are out-of-date, and
  install updated copies into the project library. (#2108)

* Fixed an issue where package installation could fail on Arch Linux with the
  error message "don't know how to check sysreqs on this system". (#2107)

* `renv` now supports profile-specific comments within `.gitignore` and
  `.renvignore` files. These are comments of the form `#| <code>`, where
  `<code>` is R code which should indicate if the `.renvignore` rules should
  apply. Typically, this should be of the form `#| profile == "extra"`, or
  `#| profile %in% c("extra", "other")`. Note that only a small subset of
  base R functions are available for evaluation in this context. Note that
  the first section in a `.renvignore` implicitly applies to all profiles --
  if you want to limit it to just the default profile, you can use
  `#| profile == "default"` for the first line. (#1662)

* The environment variable `RENV_PATHS_VERSION` can now be used to substitute
  the R version component normally used in library / cache paths. The provided
  path can include placeholders like `%V` for the full R version including
  the patch level, and `%v` for the R version without the patch level. Defaults
  to `R-%v` when unset. (#1687)

* `renv::install()` gains the `transactional` argument, for parity with
  `renv::restore()`. (#1109)


# renv 1.1.2

* `renv` gains the `sysreqs()` function, which can be used to query the system
  packages required by a set of R packages. Functionality is currently available
  for Debian-based distributions, as well as Red Hat distributions.

* On Linux, `renv` now uses the database from
  <https://github.com/rstudio/r-system-requirements> when determining if
  an R package's required system libraries are installed, and notifies
  the user which packages (if any) are missing during install / restore.

* Fixed an issue where `renv` could fail to retrieve credentials registered
  for 'github.com' when querying URLs at 'api.github.com'.

* Fixed an issue where `renv` could stall when loading a project and validating
  that the configured version of Bioconductor is compatible with the version
  of R currently in use.

* `renv::snapshot()` no longer fails to generate a new lockfile if the project
  contains a lockfile which could not be read or parsed.

* Fixed an issue where lockfiles containing unicode characters were not
  correctly written or read with versions of R (< 4.2.0) on Windows. (#2091)


# renv 1.1.1

* Fixed an issue where very long lockfiles could be truncated on write. (#2089)

* Fixed an issue where `renv` inadvertently made web requests in
  tests during `R CMD check`.


# renv 1.1.0

## Major Changes

* `renv` now includes additional package DESCRIPTION fields in the lockfile.
  This can be useful for validating the provenance of packages recorded in the
  lockfile, and also for applications using `renv` which would like to
  recompute the hash used for package caching from the lockfile itself.

  If needed, old-style lockfiles can be generated by setting the option
  `options(renv.lockfile.version = 1)`. Note that this version of `renv`
  remains compatible both with the older (minimal) lockfiles, as well
  as with the newer lockfiles in this release. (#2057)

## Other Fixes

* The `renv` sandbox is now unlocked on exit after a call to `renv::use()`.
  This should alleviate issues seen where R's attempts to clean up the
  temporary directory could fail due to inadequate permissions on the
  sandbox directory. (#2076)

* Fixed an issue where `renv::restore()` did not respect the named repository
  within the lockfile when installing packages from the archives of the
  configured package repositories. (#2081)

* Fixed an issue where `renv::snapshot()` could fail if invoked within
  a project containing empty or invalid `.ipynb` files. (#2073)

* Fixed an issue where R package installation could fail if the project
  depended on a package whose current version available from the configured
  package repositories required on a newer version of R than what was currently
  installed, even if that package need not be updated. (#2071)

* Fixed an issue where `RENV_CONFIG_EXTERNAL_LIBRARIES` was incorrectly
  split when using Windows paths. (#2069)

* Fixed an issue where `renv` failed to restore packages installed from
  r-universe when the associated lockfile record had no `RemoteRef` field.
  (#2068)

* `renv` now detects dependencies from usages of `utils::citation()`. (#2047)

* Fixed an issue where packages installed from r-universe via an explicit
  URL remote could not be restored. (#2060)

* Fixed an issue where the repositories provided to `renv::init()` were ignored
  when also initializing `renv` with a specific version of Bioconductor.

* `renv::install()` gains the `include` parameter, which can be useful when
  you'd like to install a subset of dependencies within a project while also
  respecting any declared remotes in that project's `DESCRIPTION` file. (#2055)

* Fixed an issue where `renv` could fail to check for updates for packages
  installed using `pak` without an explicit branch specified. (#2040)

* `renv::use()` no longer re-installs packages which are already installed
  and compatible with the requested packages. (#2044)

* Fixed an issue where `renv::init()` could fail when using named remotes
  in a DESCRIPTION file's `Remotes:` field. (#2055)

* Fixed an issue where ignore rules of the form `!*.*` were not parsed
  and handled correctly during dependency discovery. (#2052)

* Fixed an issue where `renv` erroneously reported that installed packages were
  cached when the cache was not writable. (#2041).

* `renv` now supports updating of currently-installed packages via `renv::install()`
  when configured to use `pak`. (#2037)

* Fixed an issue where `renv` library paths were not properly reset following
  a suspend / resume in RStudio Server. (#2036)

* `renv::run()` gains the `args` parameter, which can be used to pass command-line
  arguments to a script. (#2015)

* `renv` now infers a dependency on `rmarkdown` and `knitr` for R scripts which
  include YAML front-matter. (#2023)

* The performance of `renv`'s built-in JSON reader has been improved. (#2021)

* Fixed an issue where `renv` could erroneously create a binding called 'object'
  in the global environment on startup. (#2017)


# renv 1.0.11

* Fixed an issue where headers were not properly passed to `available.packages()`
  during `renv` bootstrap. (#1942)

* `renv` now assumes that Artifactory package repositories will use a CRAN-like
  layout of packages for packages in the archive. (#1996)

* `renv` now includes compiled extensions on Linux + macOS. These
  extensions are primarily used to improve the performance of
  `renv::dependencies()` and other static analysis code.
  Support for Windows may come in a future release.

* Fixed an issue where `renv::snapshot()` could fail if the project
  contained a call to `module()` with no arguments. (#2007)

* On Linux, `renv` now emits a message on load if the R temporary directory
  is within a folder that has been mounted as 'noexec'. This message can be
  suppressed by setting the `RENV_TEMPDIR_NOEXEC_CHECK=FALSE` environment
  variable.


# renv 1.0.10

* Fixed a performance regression in `renv::dependencies()`. (#1999)

* Fixed an issue where `renv` tests could fail if the `parallel` package was
  loaded during test execution.

* `renv` now determines a package repository's type through the HTTP headers
  provided when accessing `src/contrib/PACKAGES`. This is mainly relevant
  when detecting Nexus and Artifactory repositories.


# renv 1.0.9

* Fixed an issue where repository URLs were inappropriately transformed into
  binary repository URLs on Linux. (#1991)

* Fixed an issue where code following `source("renv/activate.R")` in the project
  `.Rprofile` was not invoked for projects using RStudio. (#1990)


# renv 1.0.8

* `renv` now infers a dependency on the `ragg` package when the `ragg_png` device
  is used in R Markdown / Quarto documents, for documents using the code
  `knitr::opts_chunk$set(dev = "ragg_png")`. (#1985)

* `renv` now automatically generates a lockfile when loading a project containing
  a `manifest.json` file (typical for application bundles published to Posit Connect).
  (#1980, @toph-allen)

* `renv::install()` now errs if an incompatible `type` argument is provided.

* `renv::checkout()` now also checks out the version of `renv` available
  and associated with the requested snapshot date. (#1966)

* Fixed an issue where `renv::hydrate()` did not hydrate packages which
  were also listed as dependencies within a project's `DESCRIPTION` file.
  (#1970)

* Fixed an issue where `renv::checkout()` omitted some fields from lockfile
  records when using `actions = c("snapshot", "restore")`. (#1969)

* `renv` gains the function `renv::retrieve()`, which can be used to download
  packages without installing them. This is primarily useful in CI / CD scenarios,
  where you might want to download packages in a single stage before attempting
  to install / restore them. (#1965)

* `renv` now preserves `Remote` fields present on packages installed from
  public package repositories (e.g. <https://r-universe.dev/>). (#1961)

* Fixed an issue where `renv::load()` could fail to load an alternate project
  when `options(renv.config.autoloader.enabled = FALSE)` was set. (#1959)

* `renv` now emits clickable hyperlinks for runnable code snippets and help,
  for front-ends which support the `ide:run` and `ide:help` ANSI escapes.

* `renv::init(bioc = "<version>")` now prompts the user in interactive sessions
  when requesting a version of Bioconductor which is not compatible with the
  current version of R. (#1943)

* `renv::restore()` gains the `transactional` argument, which can be
  used to control whether `renv` will allow successfully-installed
  packages remain in the project library even if a package fails
  to install during a later step. (#1109)

* `renv` now infers a dependency on the `xml2` package for projects
  using the `testthat::JunitReporter` for tests. (#1936)

* Fixed an issue where `renv::dependencies()` could emit a warning
  when attempting to parse chunks using chunk options like
  `#| eval: c(1, 2)`. (#1906)

* `renv::install()` now properly delegates the `type` and `rebuild`
  arguments to `pak` when `options(renv.config.pak.enabled = TRUE)`
  is set. (#1924)

* `renv` now infers a dependency on the `svglite` package if it detects
  calls of the form `ggsave(filename = "path.svg")`. (#1930)

* `renv` now supports setting of GitHub authentication credentials via
  any of `GITHUB_TOKEN`, `GITHUB_PAT`, and `GH_TOKEN`. (#1937)

* `renv` now also passes any custom headers available to
  `utils::available.packages()` during bootstrap. (#1942)

* Fixed an issue where `renv` could fail during installation of packages
  stored within repository sub-directories, if that repository also
  contained a top-level DESCRIPTION file. (#1941)

* `renv` now normalizes lockfile entries for Bioconductor packages installed
  via `pak::pkg_install()`, to help prevent spurious diffs being produced
  via `renv::status()`. (#1920)

* `renv::install()` now respects the `prompt` parameter when `pak` is enabled,
  as via `options(renv.config.pak.enabled = TRUE)`. (#1907)

* Fixed an issue with `renv`'s `pak` integration where `renv` could install the
  wrong version of a GitHub package during restore if
  `options(renv.config.pak.enabled = TRUE)` was set. (#1883)

* `renv` no longer interacts with the user during autoloading, which coincides
  with R startup. If the IDE offers a session init hook (RStudio does),
  loading is deferred until startup is complete and interaction is possible.
  Otherwise, any suggested renv actions, such as `renv::restore()`, are emitted
  as a message for the user to act on. (#1879, #1915).

* Fixed an issue where installation of packages from local sources, as via
  `install("<package>", repos = NULL, type = "source")`, could fail. (#1880)

* A new function, `renv::lockfile_validate()`, can be used to validate your `renv.lock`
  against a default or custom schema. (#1889)


# renv 1.0.7

* Fixed an issue where `renv`'s activate script failed to report version
  conflict errors when starting up. (#1874)


# renv 1.0.6

* Fixed an issue where downloads could fail with curl >= 8.7.1. (#1869)

* Fixed an issue where `renv::snapshot()` did not properly normalize
  package records generated from packages installed using the `pak`
  package, e.g. via `pak::pkg_install("cran::<package>")`.

* Fixed an issue where `renv` could incorrectly prompt the user to record
  a version of `renv` installed from GitHub in some cases. (#1857)

* `renv::load()` now delegates to `base::load()` when it detects that the
  call was likely intended for `base::load()`, but `renv::load()` was used
  instead (e.g. because `base::load()` was masked by `renv::load()`).

* `renv::update()` gains the `lock` argument, which can be used to
  instruct `renv` to automatically update the lockfile after the requested
  packages have been updated. (#1849)

* Fixed an issue where `renv` could fail to update the project autoloader
  after calling `renv::upgrade()`. (#1837)

* Fixed an issue where attempts to install binary packages from older
  PPM snapshots could fail. (#1839)

* `renv` now uses a platform-specific prefix on Linux for library and
  cache paths by default with R (>= 4.4.0). This is equivalent to setting
  `RENV_PATHS_PREFIX_AUTO = TRUE`. If necessary, this behavior can be
  disabled by setting `RENV_PATHS_PREFIX_AUTO = FALSE` in an appropriate
  R startup file. (#1211)


# renv 1.0.5

* `renv` now only writes a `.renvignore` file into the cache directory
  if the cache appears to be part of the current project.

* `renv` now reports missing system libraries as part of its ABI
  checks in `renv::diagnostics()`.

* Fixed an issue where `renv::install(lock = TRUE)` produced lockfiles
  containing records with extraneous data. (#1828)


# renv 1.0.4

* `renv::install()` gains the `lock` argument. When `TRUE`, the project
  lockfile will be updated after the requested packages have been
  successfully installed. (#1811)

* `renv` now supports the use of GitHub Enterprise servers with the
  `gitcreds` package for authentication credentials. (#1814)

* `renv::dependencies()` now treats `#| eval: !expr <...>` chunk options
  as truthy by default, implying that such chunks are scanned for their
  R package dependencies. (#1816)

* `renv::dependencies()` now requires usages of the [import](https://cran.r-project.org/package=import)
  package to be namespace-qualified in order to be handled via static
  analysis; that is, `import::from(<pkg>)` is parsed for dependencies,
  but `from(pkg)` is not. (#1815)

* `renv::load()` gains the `profile` argument, allowing one to
  explicitly load a specific profile associated with an `renv` project.
  See `vignette("profiles", package = "renv")` or
  https://rstudio.github.io/renv/articles/profiles.html
  for more details.

* `renv::dependencies()` no longer includes `R` dependency versions
  declared from a `DESCRIPTION` file in its output. (#1806)

* Fixed an issue where `renv` could fail to infer dependencies from
  R Markdown code chunks using engine 'R' (upper-case) rather than
  'r' (lower-case). (#1803)

* Fixed an issue where `renv` did not report out-of-sync packages when
  one or more packages used in the project were not installed. (#1788)

* Fixed an issue where `renv` could over-aggressively activate P3M
  repositories when initializing a project. (#1782)

* `renv::status()` now notifies the user if the version of R recorded in
  the lockfile does not match the version of R currently in use. (#1779)

* Fixed an issue where packages could appear multiple times in the lockfile,
  if that package was installed into multiple library paths. (#1781)

* Installation of historical binaries of packages is once again enabled,
  now using the [Posit Public Package Manager (P3M)](https://packagemanager.posit.co)
  service instead of Microsoft's (now defunct) MRAN service.

* `renv::init()` now respects the `Remotes:` field declared in a project's
  `DESCRIPTION` file, if any. (#1522)

* `renv::embed()` now supports Quarto Markdown (`.qmd`) files. (#1700)

* renv now sets the `R_INSTALL_TAR` environment variable to match the default
  `tar` executable (if any) when installing packages. (#1724)

* renv now uses `--ssl-revoke-best-effort` by default when downloading files
  using `curl` on Windows. (#1739)

* Fixed an issue where `renv::install()` could fail to detect incompatible
  recursive package dependencies. (#1671)

* `renv::install()` now records remote information for packages installed from
  CRAN-like repositories, and uses that information when generating a lockfile
  and restoring those packages. This helps ensure that packages installed within
  an renv project via calls like `renv::install("<pkg>", repos = "<repos>")` can
  still be successfully restored in future sessions. (#1765)

* `renv::install()` now lazily resolves project remotes. (#1755)

* `renv::init()` now respects Remotes declared within a project's `DESCRIPTION`
  file, if any.

* Calling `renv::activate()` without explicitly providing the `profile` argument
  now preserves the current profile, if any. Use `renv::activate(profile = "default")`
  if you'd like to re-activate a project using the default profile. (#1217)

* Fixed an issue where `renv` would try to prompt for the installation of
  `BiocManager` when activating a project using Bioconductor. (#1754)

* Fixed an issue where directories containing a large number of files could
  cause `renv` to fail to activate a project. (#1733)

* Expanded the set of Linux distributions detected for automatic transformation
  of Posit Package Manager URLs to install binary packages. `renv` now correctly
  detects Red Hat Enterprise Linux 9, Rocky Linux 8 and 9, SLES 15 SP4 and SP5,
  Debian 11 and 12, AlmaLinux 8 and 9, and Amazon Linux 2. (#1720, #1721)


# renv 1.0.3

* Fixed an issue where `renv` could warn the project appeared to be out-of-sync
  when using packages installed without an explicit source recorded. (#1683)

* `renv::install()` gains the `exclude` argument, which can be useful when
  installing a subset of project dependencies.

* Fixed an issue where PPM repositories were not appropriately transformed
  into the correct binary repository in `renv::restore()` when using pak.

* `renv::init()` no longer prompts the user for the intended action for
  projects containing a library with only renv installed. (#1668)

* Fixed an issue where non-interactive usages of `renv::init()` could fail
  with projects containing a DESCRIPTION file. (#1663)

* Fixed an issue that could cause code within a project `.Rprofile` to execute
  before the project had been loaded in RStudio. (#1650)

* `renv::snapshot()` and `renv::status()` gain the `dev` argument. This
  can be used when you'd like to capture package dependencies from
  the *Suggests* field of your package's DESCRIPTION file. (#1019)


# renv 1.0.2

* renv now parses package `NAMESPACE` files for imported dependencies. (#1637)

* renv no longer locks the sandbox by default.

* Fixed an issue where renv used the wrong library paths when attempting
  to activate the watchdog. This could cause a 10 second delay when activating
  the sandbox.


# renv 1.0.1

* Fixed an issue where authentication headers could be duplicated when
  using the `libcurl` download method. (#1605)

* `renv::use()` now defaults to setting `isolate = TRUE` when `sandbox = TRUE`.

* Fixed an issue where the renv watchdog could fail to load, leading to slowness
  in activating the sandbox on startup. (#1617)

* Fixed an issue where renv did not display warnings / errors from `renv::snapshot()`
  when `options(renv.verbose = FALSE)` was set. The display of these messages
  is now controlled via the `renv.caution.verbose` R option. (#1607, #1608)

* `renv::load()` now notifies the user if the synchronization check took an
  excessive amount of time due to the number of files being scanned in the
  project. (#1573)

* `renv::init()` gains the `load` argument, making it possible to initialize
  a project without explicitly loading it. (#1583)

* renv now uses a lock when synchronizing installed packages with the cache.
  This should help alleviate issues that can arise when multiple R processes
  are installing and caching packages concurrently. (#1571)

* Fixed a regression in parsing expressions within R Markdown chunk options. (#1558)

* Fixed an issue that prevented `renv::install()` from functioning
  when source-only repositories were included. (#1578)

* Fixed a logic error in reading `RENV_AUTOLOAD_ENABLED`. (#1580)

* `renv::restore()` no longer runs without prompting on load if the
  library is empty. (#1543)

* `renv::repair()` now checks for installed packages which lack a known
  remote source, and updates their `DESCRIPTION` files if it can infer an
  appropriate remote source. This typically occurs when a package is installed
  from local sources, but appears to be maintained or published on a remote
  repository (e.g. GitHub). This was previously done in `renv::snapshot()`, but
  we've rolled back that change as the prompting was over-aggressive. (#1574)

* `renv::status()` now first reports on uninstalled packages, before reporting on
  used <-> installed mismatches. (#1538)

* When the `RENV_STARTUP_DIAGNOSTICS` environment variable is set to `TRUE`,
  renv now displays a short diagnostics report after a project's autoloader
  has been run. This can be useful when diagnosing why renv is slow to load
  in certain projects. (#1557)

* renv now ensures the sandbox is activated on load, for R processes which
  are launched with the renv sandbox on the library paths. (#1565)

* `renv::restore()` no longer erroneously prompts when determining the packages
  which need to be installed. (#1544)

* `renv::update()` now ensures the `prompt` parameter is properly respected
  during package installation. (#1540)

* `renv::activate()` no longer erroneously preserves the previous library
  paths after restarting the session within RStudio. (#1530)

* Use correct spelling of IRkernel package (#1528).

* Honor `R_LIBCURL_SSL_REVOKE_BEST_EFFORT` when using an external `curl.exe`
  binary to download files. (#1624)


# renv 1.0.0

## New features

* New `renv::checkout()` installings the latest-available packages from a
  repository. For example, `renv::checkout(date = "2023-02-08")` will install
  the packages available on 2023-02-08 from the Posit
  [Package Manager](https://packagemanager.rstudio.com/) repository.
  The `actions` argument allows you choose whether a lockfile is generated from
  the provided repositories ("snapshot"), or whether packages are installed
  from the provided repositories ("restore").

* `renv::deactivate()` gains a `clean` argument: when `TRUE` it will delete
  all renv files/directories, leaving the project the way it was found.

* `renv::init()` now uses [Posit Public Package Manager](https://packagemanager.posit.co)
  by default, for new projects where the repositories have not already been
  configured externally. See the options `renv.config.ppm.enabled`,
  `renv.config.ppm.default`, and `renv.config.ppm.url` in `?config` for more
  details (#430).

* `renv::lockfile_create()`, `renv::lockfile_read()`, `renv::lockfile_write()`
  and `renv::lockfile_modify()` provide a small family of functions for
  interacting with renv lockfiles programmatically (#1438).

* Handling of development dependencies has been refined. `renv::snapshot()`
  and `renv::status()` no longer track development dependencies, while
  `install()` continues to install them (#1019). `Suggested` packages listed in
  `DESCRIPTION` files are declared as development dependencies regardless of
  whether or not they're a "package" project.

* MRAN integration is now disabled by default, pending the upcoming shutdown
  of Microsoft's MRAN service. Users who require binaries of older R packages
  on Windows + macOS can consider using the instance of CRAN mirrored by the
  [Posit Public Package Manager](https://packagemanager.posit.co) (#1343).

## Bug fixes and minor improvements

* Development versions of renv are now tracked using the Git SHA of the
  current commit, rather than a version number that's incremented on every
  change (#1327). This shouldn't have any user facing impact, but makes
  renv maintenance a little easier.

* Fixed an issue causing "restarting interrupted promise evaluation" warnings
  to be displayed when querying available packages failed. (#1260)

* `renv::activate()` uses a three option menu that hopefully make your choices
  more clear (#1372).

* `renv::dependencies()` now discovers R package dependencies inside Jupyter
  notebooks (#929).

* `renv::dependencies()` includes packages used by user profile (`~/.Rprofile`)
  if `renv::config$user.profile()` is `TRUE`. They are set as development
  dependencies, which means that they will be installed by `install()` but not
  recorded in the snapshot.

* `renv::dependencies()` only extracts dependencies from text in YAML
  headers that looks like valid R code (#1288).

* `renv::dependencies()` no longer treats `box::use(module/file)` as using
  package `module` (#1377).

* `renv::init()` now prompts the user to select a snapshot type if the project
  contains a top-level DESCRIPTION file (#1485).

* `renv::install(type = "source")` now ensures source repositories are used
  in projects using [PPM](https://packagemanager.posit.co/). (#927)

* `renv::install()` activates Bioconductor repositories when installing a
  package from a remote (e.g. GitHub) which declares a Bioconductor dependency
  (via a non-empty 'biocViews' field) (#934).

* `renv::install()` respects the project snapshot type, if set.

* `renv::install()` now keeps source when installing packages from source (#522).

* `renv::install()` now validates that binary packages can be loaded after
  installation, in a manner similar to source packages (#1275).

* `renv::install()` now supports Bioconductor remotes of the form
  `bioc::<BiocVersion>/<Package>`, for installing packages from
  a particular version of Bioconductor. Aliases like 'release' and
  'devel' are also supported (#1195).

* `renv::install()` now requires interactive confirmation that you want to
  install packages (#587).

* `renv::load()` gives a more informative message if a lockfile is present but
  no packages are installed (#353).

* `renv::load()` no longer attempts to query package repositories when checking
  if a project is synchronized (#812).

* `renv::load()` no longer duplicates entries on the `PATH` environment variable
  (#1095).

* `renv::restore()` can now use `pak::pkg_install()` to install packages
  when `pak` integration is enabled. Set `RENV_CONFIG_PAK_ENABLED = TRUE`
  in your project's `.Renviron` if you'd like to opt-in to this behavior.
  Note that this requires a nightly build of `pak` (>= 0.4.0-9000);
  see https://pak.r-lib.org/dev/reference/install.html for more details.

* `renv::restore()` now emits an error if called within a project that
  does not contain a lockfile (#1474).

* `renv::restore()` correctly restores packages downloaded and installed
  from [r-universe](https://r-universe.dev/) (#1359).

* `renv::snapshot()` now standardises pak metadata so CRAN packages installed via
  pak look the same as CRAN packages installed with renv or `install.packages()`
  (#1239).

* If `renv::snapshot()` finds missing packages, a new prompt allows you to
  install them before continuing (#1198).

* `renv::snapshot()` no longer requires confirmation when writing the first
  snapshot, since that's an action that can easily be undone (by deleting
  `renv.lock`) (#1281).

* `renv::snapshot()` reports if the R version changes, even if no packages
  change (#962).

* `renv::snapshot(exclude = <...>)` no longer warns when attempting to exclude
  a package that is not installed (#1396).

* `renv::status()` now uses a more compact display when packages have some
  inconsistent combination of being installed, used, and recorded.

* `renv::status()` now works more like `renv::restore()` when package versions
  are different (#675).

* `renv::update()` can now update packages installed from GitLab (#136) and
  BitBucket (#1194).

* `renv::settings$package.dependency.fields()` now only affects packages
  installed directly by the user, not downstream dependencies of those packages.

* renv functions give a clearer error if `renv.lock` has somehow become
  corrupted (#1027).


# renv 0.17.3

* Fixed an issue where `renv::install("bioc::<package>")` could fail if
  `BiocManager` was not already installed. (#1184)

* Fixed an issue where package names were not included in the output
  of `renv::diagnostics()`. (#1182)

* The clarity of the message printed by `renv::status()` has been improved;
  in particular, renv should better report the recommended actions when
  a package required by the project is not installed.

* `renv::snapshot()` gains the `exclude` argument, for explicitly
  excluding certain packages from the generated lockfile.

* Fixed an issue where renv was passing the wrong argument name to
  `installed.packages()`, causing usages of renv to fail with
  R (<= 3.4.0). (#1173)

* renv now sets the `SDKROOT` environment variable on macOS if it detects
  that R was built using an LLVM build of `clang` on macOS.

* `renv::install()` now parses the remotes included within, for example,
  a `DESCRIPTION` file's `Config/Needs/...` field.

* renv now checks that the index directory is writable before attempting to
  use it, e.g. for the `R` available packages index maintained by renv. (#1171)

* renv now checks that the version of `curl` used for downloads appears to
  be functional, and reports a warning if it does not (for example, because
  a requisite system library is missing). The version of `curl` used for
  downloads can also be configured via the `RENV_CURL_EXECUTABLE` environment
  variable.


# renv 0.17.2

* Fixed a regression that caused package hashes to be computed incorrectly
  in some cases. This was a regression in the 0.17.1 release. (#1168)


# renv 0.17.1

* renv gains the configuration option `install.remotes`, which can be used
  to control whether renv attempts to read and use the `Remotes:` field
  included with installed packages. This can be set to `FALSE` if you'd
  like to ignore this field; e.g. because you know they will not be
  accessible. (#1133)

* General performance optimizations. In particular, `renv::update(check = TRUE)`
  should now execute much faster.

* renv now stores project settings within `renv/settings.json` rather than
  `renv/settings.dcf`. Old settings will be automatically migrated.

* The renv sandbox is now placed within the renv cache directory. (#1158)

* Fixed an issue where `renv::status()` could erroneously report a project was
  out-of-sync when using explicit snapshots. (#1159)

* Fixed an issue where `renv::hydrate()` would print spurious warnings. (#1160)

* `renv::status()` now suggests running `renv::restore()` if there are no
  packages installed in the project library. (#1060)

* Fixed an issue where renv would fail to query [r-universe](https://r-universe.dev/)
  repositories. (#1156)

* renv no longer tries to set the `SDKROOT` environment variable on
  macOS for R (>= 4.0.0).

* Fixed an issue where installation of Bioconductor packages could fail
  when `BiocManager` was not installed. (#1156, #1155)

* Fixed an issue where the amount of time elapsed reported by `renv::install()`
  failed to include the time spent retrieving packages.


# renv 0.17.0

* The performance of `renv::snapshot()` has improved.

* renv now maintains an index of available packages, as retrieved from the
  active package repositories, that is shared across `R` sessions. This should
  improve renv's performance when querying for available packages across
  multiple different `R` sessions.

* `renv::hydrate()` gains the `prompt` parameter. When `TRUE` (the default),
  renv will prompt for confirmation before attempting to hydrate the active
  library.

* Improved handling of package installation via SSH URLs with `git`. (#667)

* Improved handling of R version validation when using projects with
  Bioconductor. If you find renv is erroneously reporting that your version
  of R is incompatible with the version of Bioconductor you are using, you can
  set `options(renv.bioconductor.validate = FALSE)` to disable this validation
  behaviour. (#1148)

* Package names can now be associated with remotes in `renv::install()`; for
  example, you can use `renv::install("igraph=igraph/rigraph")` to install
  the `igraph` package. This is mainly important when using the `renv.auth`
  authentication tools, where the package name of a remote needs to be
  declared explicitly. (#667)

* Fixed an issue that could prevent `renv::restore()` from functioning when
  attempting to install packages which had been archived on CRAN. (#1141)

* `renv::install()` gains the `dependencies` argument, which behaves similarly
  to the equivalent argument in `remotes::install_*()`. In particular, this can
  be set to fields like `Config/Needs/dev` to tell renv to use custom
  DESCRIPTION fields for dependency resolution in installation.

* Fixed an issue where the function variant of the `renv.auth` option was not
  resolved correctly. (#667)

* `renv::install()` now supports remotes with a trailing slash -- such slashes
  are now removed. (#1135)

* Integration with the RStudio (Posit) Package Manager is now disabled
  by default on aarch64 Linux instances.

* The `RENV_CACHE_MODE` environment variable can now also be used
  to adjust the permissions set on downloaded package tarballs / binaries.
  (#988)

* Fixed an issue where fields of the form `Remotes.1` could
  enter lockfile records for older versions of R. (#736)

* Fixed the performance of `renv::update()` in cases where
  integration with MRAN is enabled.

* Fixed an issue where package installation using `pak` could fail
  in some cases.

* `renv_file_find()` can now scan up to the root directory in Docker
  containers. (#1115)

* renv no longer uses the R temporary directory on Windows for the
  sandbox. The sandbox directory can be customized via the
  `RENV_PATHS_SANDBOX` environment variable if required. (#835)

* renv now reports the elapsed time when installing packages. (#1104)

* For projects using "explicit" snapshots, renv now reports if
  a package is required by the project, but the package is not
  currently installed. (#949)

* Fixed an issue where `renv::snapshot()` could fail to detect when
  no changes had been made to the lockfile.

* Fixed an issue where renv could emit JSON lockfiles which could not
  be parsed by external JSON readers. (#1102)

* renv now marks the sandbox as non-writable, which should hopefully
  alleviate issues where attempts to update installed packages would
  inadvertently install the updated package into the sandbox. (#1090)

* `renv::use()` gains the `sandbox` argument, which allows one to control
  whether the system library is sandboxed after a call to `renv::use()`.
  (#1083)

* The path to the Conda `environment.yml` file created by renv can
  now be customized via the `RENV_PATHS_CONDA_EXPORT` environment
  variable. We recommend setting this within your project-local
  `.Renviron` file as appropriate. (#1089)

* Fixed an issue where the renv sandbox location did not respect the
  active renv profile. (#1088)


# renv 0.16.0

* renv now supports installation of packages with remotes of the form
  `<package>=<remote>`. However, the provided package name is ignored
  and is instead parsed from the remote itself. (#1064)

* renv now passes along the headers produced by the `renv.download.headers`
  option when bootstrapping itself in the call to `utils::download.file()`.
  (#1084)

* renv now reports if `renv::snapshot()` will change or update the
  version of R recorded in the lockfile. (#1069)

* renv now supports the `install.packages.check.source` R option, which
  is used to allow R to query source repositories even if the option
  `options(pkgType = "binary")` is set. (#1074)

* renv better handles packages containing git submodules when installed
  from GitHub remotes. (#1075)

* renv now handles local sources within the current working directory. (#1079)

* The renv sandbox is once again enabled by default. On Unix, the sandbox
  is now created by default within the project's `renv/sandbox` library.
  On Windows, the sandbox is created within the R session's `tempdir()`.
  The path to the renv sandbox can be customized via the `RENV_PATHS_SANDBOX`
  environment variable if required.

* Fixed an issue where `renv::status()` could report spurious changes when
  comparing packages installed using `pak` in some cases. (#1070)

* `renv::restore()` now also ensures the project activate script is updated
  after a successful restore. (#1066)

* Fixed an issue where renv could attempt to install a package from the
  repository archives even when `type = "binary"` was set. (#1046)

* Fixed an issue where package installation could fail when the R session
  is configured to use multiple repositories, some of which do not provide
  any information on available packages for certain binary arms of the
  repository. (#1045)

* renv now uses `jsonlite` for reading lockfiles when loaded. This should
  help ensure useful errors are provided for manually-edited lockfiles
  which contain a JSON parsing error. If the `jsonlite` package is not loaded,
  renv will fall back to its own internal JSON parser. (#1027)

* Fixed an issue that would cause renv to fail to source the user
  `~/.Rprofile` if it attempted to register global calling handlers,
  e.g. as `prompt::set_prompt()` does. (#1036)

* (Linux only) renv now resets ACLs on packages copied to the cache, to
  avoid persisting default ACLs that might have been inherited on packages
  installed into a local project library. If desired, this behavior can be
  disabled by setting the `RENV_CACHE_ACLS` environment variable to `FALSE`.
  If you need finer control over ACLs set on packages moved into the cache,
  consider defining a custom callback via the `renv.cache.callback` R option.
  (#1025)

* Fixed an issue where `.gitignore` inclusion rules for sub-directories were
  not parsed correctly by renv for dependency discovery. (#403)

* Fixed an issue where renv could report spurious diffs within `renv::status()`
  when comparing package records installed from `pak` versus the default R
  package installer. (#998)

* Fixed an issue where `renv::use_python()` could cause the Requirements field
  for packages in the lockfile to be unintentionally dropped. (#974)

* The R option `renv.cache.callback` can now be set, to run a user-defined
  callback after a package has been copied into the cache. This can be useful
  if you'd like to take some action on the cached package's contents after
  the package has been moved into the cache.

* (Unix only) The `RENV_CACHE_MODE` environment variable can now be used to
  change the access permissions of packages copied into the cache. When set,
  after a package is copied into the cache, renv will use `chmod -Rf` to try
  and change the permissions of the cache entry to the requested permissions.

* (Unix only) The `RENV_CACHE_USER` environment variable can now be used to
  change the ownership of folders copied into the cache. When set, after a
  package is copied into the cache, renv will use `chown -Rf` to try and
  change the ownership of that cache entry to the requested user account.

* Fixed an issue where repositories containing multiple packages in
  sub-directories could fail to install. (#1016)


# renv 0.15.5

* Fixed an issue where indexing of packages in the package cellar could
  be slow. (#1014)

* Fixed an issue where installation of packages from Bioconductor's binary
  Linux package repositories could fail. (#1013)

* `renv::restore()` now supports restoration of packages installed from
  [R-Forge](https://r-forge.r-project.org/). (#671)

* Fixed an issue where `renv::init(bioconductor = TRUE)` would not update
  the version of Bioconductor used if a project setting had already been
  set.

* It is now possible to "update" an existing lockfile by using
  `renv::snapshot(update = TRUE)`. When set, any records existing in the
  old lockfile, but not the new lockfile, will be preserved. (#727)

* Fixed an issue where renv could fail to parse Git remotes for users
  whose username contains a number. (#1004)

* renv no longer infers a dependency on the "quarto" R package in projects
  containing a `_quarto.yml` file. (#995)

* Fixed an issue where renv could fail to download a package from MRAN if
  a compatible source package of the same version was available from the
  active R repositories. (#990)

* renv now reports permission errors during download more clearly. (#985)

* Fixed an issue where `RENV_PATHS_LIBRARY_ROOT_ASIS` was not interpreted
  correctly. (#976)

* `renv::modify()` gains the `changes` argument, which can be used to modify
  a project lockfile non-interactively.

* `renv::clean()` now returns the project directory, as documented. (#922)

* Fixed an issue where renv could fail to parse embedded YAML chunk options
  in R Markdown documents. (#963)

* renv now sets default placeholder names for the `repos` R option, for
  any repository URLs which happen to be unnamed. (#964)

* Fixed an issue where renv didn't respect the `PATH` ordering when
  discovering Python installations via `renv_python_discover()`. (#961)

* Fixed an issue where renv could fail to install packages containing
  multibyte unicode characters in their DESCRIPTION file. (#956)

* Fixed detection of Rtools 4.2 (#1002)


# renv 0.15.4

* Fixed an issue where package installation could fail when referencing the
  cache via a tilde-aliased path, e.g. `~/.local/share/renv`. (#953)


# renv 0.15.3

* A variety of fixes for R CMD check.

* renv gains an experimental function, `renv::autoload()`, to be used as a
  helper for automatically loading a project for R processes launched within a
  sub-directory of that project. See `?renv::autoload` for more details.

* renv will now print a warning message when attempting to read a lockfile
  containing merge conflict markers (as from e.g. a git merge). (#945)

* Fixed an issue where `renv::install()` could install into the wrong library
  path on Windows, if the R installation had a site-wide profile that mutated
  the library paths. (#941)

* Fixed an issue where `renv::install()` would fail to find a package within
  the cache when using an abbreviated commit hash for installation. (#943)

* Fixed an issue where renv's automatic snapshot was not run after calls to
  `renv::install()` in some cases. (#939)

* Fixed an issue where renv would incorrectly copy a package from the cache,
  if the cached version of the package and the requested version of the package
  had the same package version, even if they were retrieved from different
  sources. (#938)

* The path to an renv tarball can now be set via the environment variable
  `RENV_BOOTSTRAP_TARBALL`, to be used to help renv bootstrap from local
  sources. This can either be the path to a directory containing renv
  source tarballs, or the path to the tarball itself.

* Fixed an issue where the R site library would not be appropriately masked
  for resumed RStudio sessions. (#936)


# renv 0.15.2

* Fixed issues encountered in R CMD check.


# renv 0.15.1

* Fixed an issue where renv inadvertently inserted extra newlines into
  a `DESCRIPTION` file when adding `Remotes` fields after install. (#914)

* Fixed an issue where packages installed from a remote sub-directory would
  fail to install when later re-installed from the cache. (#913)

* renv now recognizes YAML chunk options of the form `#| key: value` when
  used in R Markdown documents. (#912)

* Fixed an issue where the R site library was visible in renv projects with
  the system library sandbox disabled.

* Fixed an issue where renv could update the wrong `.gitignore` in R
  processes launched by `callr` (e.g. in `devtools::install`). (#910)

* Fixed an issue where renv could fail to read mis-encoded
  DESCRIPTION files. (#908)

* Fixed an issue where `config$cache.symlinks()` would report `NULL` when
  unset. (#906)


# renv 0.15.0

* The development branch for renv has moved from master to main.

* renv package records in the lockfile now include a `Requirements`
  entry, which gives a list of R packages this package depends on
  in some way. This is primarily for internal use by the `pak`
  package.

* Fixed an issue where packages containing DESCRIPTION files using
  a latin1 encoding would not be read correctly by renv.

* Fixed an issue that could cause `renv::dependencies()` to fail
  when a malformed `DESCRIPTION` file was encountered. (#892)

* The path to the project-local renv folder can now be configured
  via the `RENV_PATHS_RENV` environment variable. This can be useful
  if you'd prefer to store your project's renv resources within
  an alternate location in the project. (#472)

* renv now uses an external library by default for R package projects,
  with the library located within `tools::R_user_dir("renv", "cache")`.
  This directory can be configured via the `RENV_PATHS_LIBRARY_ROOT`
  environment variable if desired. See
  `vignette("packages", package = "renv")` for more details. (#384)

* renv now uses the repositories as defined within the project lockfile
  (if any) when attempting to bootstrap itself in a project. (#820)

* The renv sandbox is now disabled by default -- see #614 for more details.

* renv gains the function `repair()`, to be used to attempt to repair
  the project library when links into the global package cache appear to
  be broken. (#378)

* Fixed an issue where the staging library used during install could fail to
  inherit the same directory permissions as the target library itself. (#331)

* Fixed an regression which caused `renv::history()` to fail. (#886)

* renv gains experimental support for the [pak](https://pak.r-lib.org/)
  package. Set `RENV_CONFIG_PAK_ENABLED = TRUE` in an appropriate `.Renviron`
  file to enable `pak` integration. When enabled, calls to `renv::install()`
  will use `pak` to download and install packages.

* `renv::init()` gains the `bioconductor` argument, to be used to initialize
  a project with a particular Bioconductor release. You can also use
  `renv::init(bioconductor = TRUE)` to initialize with the latest-available
  release for the version of R being used.

* Project settings can now be overridden by setting an R option of the same
  name. For example, one could force a project to use Bioconductor 3.14 by
  setting `options(renv.settings.bioconductor.version = "3.14")` within
  the project `.Rprofile` (or similar startup R profile).

* The ad-hoc package repository called "local sources" has been renamed to
  the "package cellar". In addition, the path to the cellar is now
  controlled by the `RENV_PATHS_CELLAR` environment variable, rather than
  `RENV_PATHS_LOCAL`. This change was made to reduce confusion between
  "local sources" of packages located somewhere on the filesystem, as
  opposed to packages explicitly placed in this ad-hoc repository.
  `RENV_PATHS_LOCAL` remains supported for backwards compatibility.

* The `RENV_PATHS_CELLAR` environment variable can now be set to multiple
  paths. Use `;` as a separator between paths; for example,
  `RENV_PATHS_LOCAL=/path/to/sources/v1;/path/to/sources/v2`. (#550)

* Packages installed via e.g. `renv::install("./path/to/package")`
  will now retain the relative path to that package within the lockfile.
  (#873)

* Fixed an issue where invalid `config` option values were not properly
  reported. (#773)

* renv now supports restoration of packages installed via one of the
  [r-universe](https://r-universe.dev/) repositories.

* renv gains the `bioconductor.version` project setting, used to freeze
  the version of Bioconductor used in a particular project. When set, this
  will override any version that might be selected via the `BiocManager`
  package. (#864)

* renv now infers that parameterized R Markdown documents have a dependency
  on the `shiny` package. In addition, R code included within the `params:`
  list will be parsed for dependencies. (#859)

* renv now ignores hidden directories during dependency discovery by default.
  If you want to force a particular hidden directory to be included for
  discovery, you can use a `.renvignore` file with an explicit inclusion
  criteria; e.g. `!.hidden/`.

* renv now supports the `*release` remotes specifier for GitHub repositories,
  for requesting installation of the latest declared release of a package from
  GitHub. (#792)

* renv now handles packages stored within the sub-directory of a Git
  repository better. (#793)

* Fixed an issue where `renv::history()` would fail to resolve the correct
  lockfile path if the working directory was changed. (#834)

* Refined dependency discovery within `glue::glue()` expressions.

* renv now parses packages referenced via the `base_format` field within
  an R Markdown document's YAML header. (#854)

* Fixed an issue where renv would fail to produce the appropriate binary
  repository URL for RSPM repositories built using Red Hat Enterprise Linux.

* Fixed an issue where `renv::snapshot()` could cause the environment name
  and / or path associated with a Python environment to be omitted from the
  lockfile. (#843)

* Fixed an issue where `renv::restore()` could fail to restore packages which
  referred to their source via an explicit path in the `Source` field. (#849)

* renv no longer requires explicit user consent when used within Singularity
  containers. (#824, @kiwiroy)

* renv now respects the `R_PROFILE_USER` environment variable, in addition
  to the `user.profile` configuration option, when considering whether the
  user `.Rprofile` should be examined for package dependencies. (#821)

* The renv auto-loader can now be disabled by setting the environment
  variable `RENV_AUTOLOADER_ENABLED = FALSE`. This can be useful if you'd like
  to explicitly control how a project is loaded, e.g. by calling `renv::load()`
  explicitly.

* `renv::snapshot()` gains the `repos` argument, to be used to force
  the lockfile to be generated with the requested set of R repositories
  encoded within.

* renv now validates that the `repos` option, as used by `renv::snapshot()`,
  is a named vector. (#811)

* Fixed an issue where renv's shims, e.g. for `install.packages()`, failed
  to pass along other optional arguments to the shimmed function correctly.
  (#808)


# renv 0.14.0

* renv now uses `tools::R_user_dir()` to resolve the default path to the
  global renv cache, for R installations 4.0.0 or greater. If the renv
  cache still exists at the old location, that location will be used instead.
  This change should only affect brand new installations of renv on newer
  versions of `R`.

* Fixed an issue with renv tests failing with R (>= 4.2.0).

* renv will no longer auto-activate itself within R processes launched via
  `R CMD INSTALL`. This behavior can be controlled if necessary via the
  `RENV_ACTIVATE_PROJECT` environment variable -- set this to `TRUE` to
  force the project in the current working directory to be activated, and
  `FALSE` to suppress the renv auto-loader altogether. (#804)

* Added dependency discovery support for R utility scripts identified by a
  shebang line instead of a file extension. (#801; @klmr)

* Fixed an issue where `renv::install("<package>", type = "both")` would attempt
  to install the package from sources, even if the current system did not have
  the requisite build tools available. (#800)

* `renv::scaffold()` gains the `settings` argument, used to create a project
  scaffolding with some default project options set. (#791)

* renv now determines the default branch name for packages installed from
  GitLab without an explicit reference supplied; for example, as in
  `renv::install("gitlab::<user>/<repo>")`. (#795)

* renv now infers a dependency on the `bslib` package for R Markdown
  documents using custom themes. (#790)

* renv will now prompt users to activate the current project when calling
  `renv::snapshot()` or `renv::restore()` from within a project that has not
  yet been activated. (#777)

* renv now has improved handling for `git` remotes. (#776; @matthewstrasiotto)

* `renv::restore()` gains the `exclude` argument, used to exclude a subset of
  packages during restore. (#746)

* Fixed an issue where `renv::dependencies()` could fail to parse
  dependencies in calls to `glue::glue()` that used custom open
  and close delimiters. (#772)

* Fixed an issue where `renv::init(bare = TRUE)` would unnecessarily
  scour the project for R package dependencies. (#771)

* Fixed an issue where renv could fail to install packages located
  on GitHub within sub-subdirectories. (#759)

* renv gains the function `embed()`, used to embed a lockfile with an
  R document (via a call to `renv::use()`).

* `renv::use()` gains the lockfile argument. This can be useful for
  R Markdown documents and scripts that you'd like to run with the
  context for a particular lockfile applied.

* `renv::rebuild()` gains the `type` parameter, for parity with
  `renv::install()`.

* Fixed an issue where renv could incorrectly copy an incompatible version
  of an R package from a site library into the project library during install.
  (#750)

* `renv::dependencies()` can now parse (some) usages of `parsnip::set_engine()`.

* `renv::dependencies()` now has improved handling for piped expressions.

* Fixed crash during dependency discovery when encountering `box::use()`
  declarations that use a trailing comma, and no longer treat `.` and `..` as
  package names. (@klmr)

* `renv::clean()` no longer attempts to clean the system library by default.
  (#737)

* Fixed an issue where `install.packages()` could fail when used within an
  renv project to install a package from local sources. (#724)

* The chunk `renv.ignore` parameter can now be set to `FALSE`. When set,
  renv will explicitly parse dependencies from chunks even if other
  chunk metadata would have told renv to ignore it (e.g. because it
  was marked with `eval=F`). (#722)

* Fixed an issue where chunks with the chunk option `eval=F` would
  still be scanned for dependencies. (#421)

* In interactive sessions, `renv::use_python()` will now prompt for
  the version of Python to be used. Python installations in a set
  of common locations will be searched. See `?renv::use_python()`
  for more details.

* Fixed an issue where renv would fail to retrieve packages from the
  archives if the lockfile entry was tagged with a `RemoteSha` field.

* `renv::restore()` will now prefer restoring packages from the repository
  named in the `Repository` field if available. The name is matched against
  the repository names set in the R `repos` option, or as encoded in the
  renv lockfile. (#701)

* renv now supports the discovery of dependencies within interpolated strings
  as used by the `glue` package.

* `RENV_CONFIG_EXTERNAL_LIBRARIES` can now be configured to use multiple
  library paths, delimited by either `:`, `;`, or `,`. (#700)

* renv gains the configuration option, `exported.functions`, controlling
  which functions and objects are placed on the R search path when renv
  is attached (e.g. via `library(renv)`). Set this to `NULL` to instruct renv
  not to place any functions on the search path. This helps avoid issues with,
  for example, `renv::load()` masking `base::load()`. When set, all usages
  of renv APIs must be explicitly qualified with the `renv::` prefix.


# renv 0.13.2

* `renv::install("user/repo/subdir with spaces")` now works as expected. (#694)

* renv can now parse package dependencies declared by
  `targets::tar_option_set(packages = <...>)`. (#698)

* renv no longer performs an automatic snapshot following a user-canceled
  renv action -- for example, if `renv::restore()` is canceled, the next
  automatic snapshot will be suppressed. (#697)

* Added the `vcs.ignore.local` project setting, to control whether the
  project's `renv/local` folder is added to renv's VCS ignore file
  (e.g. `renv/.gitignore`). (#696)

* Fixed an issue where renv's bootstrapping code could inadvertently bootstrap
  with the wrong version of renv, if the source and binary versions of renv
  on CRAN were not in sync. (#695)

* Fixed an issue where `renv::status()` could provide a misleading message
  for packages which are recorded in the lockfile, but not explicitly
  required by the project. (#684)


# renv 0.13.1

* `renv::clean()` gains the `actions` argument, allowing the caller to control
  which specific actions are taken during a `clean()` operation.

* renv no longer performs an automatic snapshot after a call to
  `renv::status()`. (#651)

* Fixed an issue where attempts to transform RSPM repository URLs could
  fail if the copy of R was installed without a local `CRAN_mirrors.csv`
  file.

* Fixed an issue where `renv::init()` could fail when passed a relative
  path to a directory. (#673)

* Fixed an issue where `renv::dependencies()` would miss dependencies in
  R Markdown YAML headers containing multiple output formats. (#674)

* `renv::install()` now better respects the `Remotes` field in a project
  `DESCRIPTION` file, if available. (#670)

* `RENV_DOWNLOAD_METHOD` is now treated as an alias for
  `RENV_DOWNLOAD_FILE_METHOD`.

* Fixed an issue where renv would fail to load if the `~/.Rprofile` existed
  but was an empty file.

# renv 0.13.0

* `renv::snapshot()` no longer creates an `renv/activate.R` file in the project
  folder if one does not already exist. (#655)

* The `renv::hydrate()` function gains the `update` argument, used to control
  whether `renv::hydrate()` chooses to update packages when invoked. When set
  to `TRUE`, if the version of a package installed in the source library is
  newer than that of the project library, then renv will copy that version
  of the package into the project library. (#647)

* The `RENV_PATHS_PREFIX_AUTO` environment variable can now be set to instruct
  renv to include an OS-specific component as part of the library and
  cache paths. This is primarily useful for Linux systems, where one might
  want to share a global cache with multiple different operating systems.
  The path component is constructed from the `ID` and `VERSION_CODENAME` /
  `VERSION_ID` components of the system's `/etc/os-release` file.

* renv's dependency discovery machinery now has preliminary support
  for packages imported via the [box](https://github.com/klmr/box) package;
  e.g. `box::use(dplyr[...])`.

* Multiple cache paths can now be specified, with each cache path separated
  by either a `;` or `:`. This can be useful when you'd like to use multiple
  package caches within the same project; for example, because you'd like to
  share a read-only cache with a set of projects. (#653, @vandenman)

* Fixed an issue where renv could fail to discover dependencies in directories
  with very large `.gitignore` or `.renvignore` files. (#652)

* renv gains a new configuration option, `install.shortcuts`. When enabled,
  if renv discovers that a package to be installed is already available in
  the user or site libraries, renv will instead install a copy of that package
  into the project library. (#636)

* renv gains a new function, `renv::use()`, used to download, install, and
  load a set of packages directly within an R script. `renv::use()` can make it
  easier to share a standalone R script, with the packages required to install
  that script embedded directly in the script. It is inspired in part by the
  [groundhog](https://groundhogr.com/) package.

* `renv::install(".")` can now be used to install a package from sources within
  the current working directory. (#634)

* Fixed an issue where `renv::update()` could fail if a package installed from
  GitHub was missing the `RemoteHost` field in its DESCRIPTION file. (#632)

* renv now has support for custom project profiles. Profiles can be used to
  activate different sets of project libraries + lockfiles for different workflows
  in a given project. See `vignette("profiles", package = "renv")` for more
  details.

* Fixed an issue where attempts to initialize an renv project in a path
  containing non-ASCII characters could fail on Windows. (#629)

* Fixed an issue where `renv::install("<package>")` could fail if renv chose
  to install the package from MRAN rather than from one of the active package
  repositories. (#627)

* renv again defaults to using the project's `renv/staging` folder for staged
  / transactional installs. Use the `RENV_PATHS_LIBRARY_STAGING` environment
  variable if more granular control over the staging library path is required.
  This fixes issues on Windows with creating junction points to the global
  package cache on Windows. (#584)

* renv no longer skips downloading a requested source package if an existing
  cached download exists and appears to be valid. This should help avoid issues
  when attempting to install a package whose associated tarball has changed
  remotely. (#504)

* During bootstrap, renv will now attempt to download and unpack a binary
  copy of renv if available from the specified package repositories.

* renv now always attempts to bootstrap itself from the R Project's
  Cloud package repository, as a fallback in case no other repository
  is available. (#613)

* `renv::rebuild(<package>)` now uses the latest-available version of the
  requested package(s) if those packages are not currently installed.

* Fixed an issue where `renv::restore(library = "/path/to/lib")` would fail to
  restore packages, if those packages were already installed on the active
  library paths (as reported by `.libPaths()`). (#612)

* `renv::snapshot()` gains the `reprex` argument. Set this to `TRUE` if you'd
  like to embed an renv lockfile as part of a reproducible example, as
  generated by the [`reprex`](https://tidyverse.org/help/#reprex-pkg)
  package.

* `renv::status()` now reports packages that are referenced in a project's
  scripts, but are neither installed in the project library nor recorded in the
  lockfile. (#588)

* Fixed an issue where package installation could fail if the `configure.vars`
  option was set to be a named character, rather than a named list. (#609)


# renv 0.12.5

* Fixed an issue where renv would fail to bootstrap. (#608)


# renv 0.12.4

* renv now invalidates the available packages cache if the `https_proxy`
  environment variable changes. (#579)

* `renv::install(<pkg>)` will now install the latest-available version of
  that package from local sources, if that package is available and newer than
  any package available on the active package repositories. (#591)

* The configuration option `startup.quiet` has been added, allowing one to
  control whether renv will display the typical startup banner when a
  project is loaded.

* renv now better handles being unloaded and reloaded within the
  same R session. In particular, warnings related to a corrupted
  lazy-load database should no longer occur. (#600)

* renv no longer reinstalls packages that are already installed and
  up-to-date in bare calls to `renv::install()`.

* renv now uses the R temporary directory for staging, when performing
  transactional restores / installs. If you need to control the path used
  for staged installs, please set the `RENV_PATHS_LIBRARY_STAGING` environment
  variable.

* The `install.verbose` configuration option has been added. When set to
  `TRUE`, renv will stream the output generated by R when performing a
  package installation. This can be helpful in some cases when diagnosing
  a failed restore / install. (#330)

* Fixed an issue where renv could fail to parse R Markdown chunk headers
  with an empty label. (#598)

* The environment variable `RENV_PATHS_LIBRARY_ROOT_ASIS` can now be used
  to control whether the project name should be used as-is when forming the
  library path within the `RENV_PATHS_LIBRARY_ROOT` folder. Set this to
  `"TRUE"` if you would prefer renv did not append a unique identifier
  to your project's library path. (#593)

* Fixed an issue where GitLab references were not URL encoded. (#590)

* renv no longer emits warnings when parsing multi-mode R files that make
  use of re-used knitr chunks (those specified as `<<label>>`). (#586)

* The library used for staged installs can now be configured via the
  `RENV_PATHS_LIBRARY_STAGING` environment variable. (#584)

* Fixed an issue where bootstrapping an older version of renv could
  fail if the R repositories had not been appropriately set.


# renv 0.12.3

* Fixed an issue where `renv::dependencies()` could give an error if called
  with a `path` argument of length > 1.

* `renv::restore()` gains the `rebuild` argument, allowing users to control
  whether packages should be rebuilt on `restore()` rather than installed
  via links or copies from the cache, or other sources providing
  already-installed packages.

* renv will now attempt to bootstrap itself from CRAN, in addition to any
  repositories declared via `getOption("repos")`. If you'd prefer to disable
  this behavior, you can set `options(renv.bootstrap.repos = character())`.

* The renv setting `r.version` has been added. This can be set if you'd like
  to associate a particular project with a specific version of R, independent
  of the version of R actually used when subsequent lockfiles are created via
  `renv::snapshot()`. For example, setting `renv::settings$r.version("4.0")`
  will ensure that R version `"4.0"` is encoded in the lockfile for future
  calls to `renv::snapshot()` in a project. (#254)

* `renv::dependencies()` now detects the usage of R packages within dotfiles;
  e.g. the project `.Rprofile`. (#569)

* `renv::status()` gains the `cache` argument, used to control whether
  `renv::status()` also performs diagnostics on the global package cache. (#570)

* Fixed an issue where `renv::status()` would make an un-necessary call to
  `renv::dependencies()`. (#570)

* Fixed an issue where `renv::install("bioc::<package>", rebuild = TRUE)` would
  fail to install the requested package. (#565)

* Fixed an issue where the repository name for a package installed from
  an R package repository was sometimes incorrect. (#402)

* When `RENV_PATHS_LIBRARY_ROOT` is set, renv will now disambiguate library
  paths based on a hash of the project's path. (#564)


# renv 0.12.2

* renv no longer errs when running tests with `_R_CHECK_SUGGESTS_ONLY_=false`.


# renv 0.12.1

* renv now ensures all of its dependencies are loaded eagerly when running
  tests, to avoid issues with missing + lazily-loaded packages.

* `renv::snapshot()` now accepts library paths specified with a relative
  path. (#562)

* `renv::snapshot()` no longer excludes the project itself, for `R` package
  projects that use `golem`. (#538)

* The renv configuration option `cache.symlinks` can now be used to control
  whether renv used symlinks into the cache, as opposed to full package
  copies. Please see `?renv::config` for more details. (#556)

* `renv::snapshot()` gains the `packages` argument, to be used when creating a
  lockfile that captures a specific set of packages and their dependencies.
  renv will use the currently-installed versions of those packages when
  determining the package records to be written to the lockfile. (#554)

* `renv::dependencies()` now accepts an R function as the first argument,
  for finding the packages used by a particular function. Currently,
  package usages must be prefixed with `::` to be detected. (#554)

* `renv::record(<package>)` now ensures that the latest-available version of
  that package is recorded in the lockfile. Previously, a package record
  without any specified version was added instead. For existing records
  without a recorded version, the latest-available version on the package
  repositories will be used during `restore()` instead. (#540)

* renv now reads the default branch tagged for repositories created on GitHub,
  ensuring that calls of the form `renv::install("<user>/<repo>")` resolve to
  the declared default branch, rather than always defaulting to `"master"`.
  (#557)

* renv now only installs packages from sources if it detects that build tools
  are available. This determination is done by checking whether `make` is
  available on the `PATH`. (#552)

* Warnings related to unknown sources can now be suppressed by setting
  `options(renv.warnings.unknown_sources = FALSE)`. (#546)

* renv now ignores chunks with the parameter `exercise=TRUE` set, under the
  assumption that such chunks might contain errors and so otherwise be
  un-parsable.

* renv now warns if sandbox generation takes a long time (> 30 seconds).

* renv now provides an optional locking mechanism, to help minimize the
  chance of interprocess conflicts when multiple R processes need to use the
  same renv project. The option is currently disabled by default; it can be
  enabled by setting `options(renv.config.locking.enabled = TRUE)` in an
  appropriate R startup file. (#525)


# renv 0.12.0

* renv now uses R's internal tar implementation by default on Windows. This is
  done to avoid issues that may occur when a version of `tar.exe` on the `PATH`
  exists, but does not accept Windows-style paths. The `TAR` environment
  variable can be set if one needs to explicitly force the use of a particular
  `tar.exe` executable. (#521)

* renv now prepends `renv (<version>)` to the user agent string. This should
  help ensure that package binaries are located when installing packages from
  RSPM outside of RStudio. (#520)

* renv now uses a task callback to detect mutations to the project library
  when the `auto.snapshot` configuration option is enabled. This will help
  ensure that automatic snapshots occur when packages are installed via a
  mechanism not explicitly understood by renv. (#501)

* renv now treats the user + site libraries as package sources during a
  restore. If renv sees that a package already installed in one of these
  libraries is compatible with the record requested via `renv::install()` or
  `renv::restore()`, that copy of the package will be copied and used. (#492)

* renv now performs a lighter-weight check as to whether the project lockfile
  is synchronized with the project library on load. The default value for the
  `synchronized.check` config option has been changed back to `TRUE`. (#496)

* renv now handles the `remotes` syntax for installing packages lying within
  the sub-directory of a GitHub repository; that is,
  `renv::install("user/repo/subdir")` should work as expected. (#497)

* Fixed an issue where renv did not construct the correct URL for packages to
  be installed from Bitbucket remotes. (#494)

* Fixed an issue where the `RENV_PATHS_PREFIX` environment variable was
  inappropriately normalized when renv was loaded. (#465)


# renv 0.11.0

* Fixed an issue where `renv::install(..., type = "binary")` would
  still attempt to install packages from sources in some cases. (#461)

* renv now always writes `renv/.gitignore`, to ensure that the appropriate
  directories are ignored for projects which initialize `git` after renv
  itself is initialized. (#462)

* R Markdown documents with the `.Rmarkdown` file extension are now parsed for
  dependencies.

* Fixed an issue where setting the `external.libraries` configuration option
  would trigger a warning. (#452)

* Improved handling of unicode paths on Windows. (#451)

* `renv::snapshot(project = <path>)` now properly respects `.gitignore` /
  `.renvignore` files, even when that project has not yet been explicitly
  initialized yet. (#439)

* The default value of the `synchronized.check` option has been changed from
  TRUE to FALSE.

* Fixed an issue where packages downloaded from Bitbucket and GitLab did not
  record the associated commit hash.

* Fixed an issue where attempting to install packages from GitLab could fail
  to install the correct version of the package. (#436)

* `renv::snapshot()` now preserves records in a lockfile that are only
  available for a different operating system. This should make it easier
  to share lockfiles that make use of platform-specific packages. (#419)

* renv better handles files that are removed during an invocation to
  `renv::dependencies()`. (#429)

* The configuration option `install.staged` has been renamed to
  `install.transactional`, to better reflect its purpose. `install.staged`
  remains supported as a deprecated alias.

* Fixed an issue where renv could fail to parse non-ASCII content on Windows.
  (#421)

* `renv::update()` gains the `exclude` argument, useful in cases where one
  would like to update all packages used in a project, except for a small
  subset of excluded packages. (#425)

* `renv::update()` now respects the project `ignored.packages` setting. (#425)

* Fixed an issue where RSPM binary URL transformations could fail for
  Ubuntu Trusty. (#423)

* renv now records the `OS_type` reported in a package's `DESCRIPTION` file
  (if any), and ignores packages incompatible with the current operating
  system during restore. (#394)


# renv 0.10.0

* `renv::install()` gains the `type` argument, used to control whether renv
  should attempt to install packages from sources (`"source"`) or using
  binaries (`"binary"`).

* renv now knows how to find and activate Rtools40, for R 4.0.0 installations
  on Windows.

* The `RENV_PATHS_PREFIX` environment variable can now be used to prepend an
  optional path component to the project library and global cache paths.
  This is primarily useful for users who want to share the renv cache across
  multiple operating systems on Linux, but need to disambigutate these paths
  according to the operating system in use. See `?renv::paths` for more details.

* Fixed an issue where `renv::install()` could fail for packages from GitHub
  whose DESCRIPTION files contained Windows-style line endings. (#408)

* `renv::update()` now also checks and updates any Bioconductor packages
  used within a project. (#392)

* renv now properly parses negated entries within a `.gitignore`; e.g.
  `!script.R` will indicate that renv should include `script.R` when
  parsing dependencies. (#403)

* Fixed an issue where packages which had only binaries available on a
  package repository were not detected as being from a package repository.
  (#402)

* Fixed an issue where calls of the form `p_load(char = <vctr>)` caused a
  failure when enumerating dependencies. (#401)

* Fixed an issue where `renv::install()` could fail when multiple versions
  of a package are available from a single repository, but some versions of
  those packages are incompatible with the current version of R. (#252)

* Fixed an issue where downloads could fail when the associated pre-flight
  HEAD request failed as well. (#390)

* Fixed an issue where empty records within a DESCRIPTION file could cause
  `renv::dependencies()` to fail. (#382)

* renv will now download binaries of older packages from MRAN when possible.

* renv will now attempt to re-generate the system library sandbox if it is
  deleted while a session is active. (#361)

* Fixed an issue where Python packages referenced using `reticulate::import()`
  were incorrectly tagged as R package dependencies. Similarly, renv now only
  considers calls to `modules::import()` if those calls occur within a call to
  `modules::module()`. (#359)

* `renv::scaffold()` now also generates a lockfile when invoked. (#351)

* The argument `confirm` has been renamed to `prompt` in all places where it
  is used. `confirm` remains supported for backwards compatibility, but is no
  longer explicitly documented. (#347)

* The continuous integration renv vignette now also contains a template for
  using renv together with GitLab CI. (#348, @artemklevtsov)

* renv now properly resets the session library paths when calling
  `renv::deactivate()` from within RStudio. (#219)

* `renv::init()` now restores the associated project library when called in a
  project containing a lockfile but no project library nor any pre-existing
  project infrastructure.

* Fixed an issue on Windows where attempts to download packages from package
  repositories referenced with a `file://` scheme could fail.

* The configuration option `dependency.errors` has been added, controlling how
  errors are handled during dependency enumeration. This is used, for
  example, when enumerating dependencies during a call to `renv::snapshot()`.
  By default, errors are reported, and (for interactive sessions) the user is
  prompted to continue. (#342)

* `renv::dependencies()` gains two new arguments: the `progress` argument
  controls whether renv reports progress while enumerating dependencies,
  and `errors` controls how renv handles and reports errors encountered
  during dependency discovery. The `quiet` argument is now soft-deprecated,
  but continues to be supported for backwards compatibility. Specifying
  `quiet = TRUE` is equivalent to specifying `progress = FALSE` and
  `errors = "ignored"`. Please see the documentation in `?dependencies`
  for more details. (#342)

* The environment variable `RENV_PATHS_LIBRARY_ROOT` can now be set, to
  instruct renv to use a particular directory as a host for any project
  libraries that are used by renv. This can be useful for certain cases
  where it is cumbersome to include the project library within the project
  itself; for example, when developing an R package. (#345)

* The code used to bootstrap renv (that is, the code used to install renv
  into a project) has been overhauled. (#344)

* renv no longer unsets an error handler set within the user profile when
  loading a project. (#343)

* renv gains the "explicit" snapshot type, wherein only packages explicitly
  listed as dependencies within the project `DESCRIPTION` file (and those
  package's transitive dependencies) will enter the lockfile when
  `renv::snapshot()` is called. (#338)

* renv will now transform RSPM source URLs into binary URLs as appropriate,
  allowing renv to use RSPM's binary repositories during restore. See
  `?config` for more details. (#124)

* renv will now infer a dependency on `hexbin` in projects that make
  use of the `ggplot2::geom_hex()` function.

* renv now tries to place Rtools on the PATH when a package is installed
  with the `install.packages()` hook active. (#335)


# renv 0.9.3

* Fixed an issue where attempts to specify `RENV_PATHS_RTOOLS` would
  be ignored by renv. (#335)

* Fixed an issue where downloads could fail when using the `wininet`
  downloader, typically with a message of the form
  "InternetOpenUrl failed: 'The requested header was not found'".

* renv better handles projects containing special characters on Windows.
  (#334)

* renv better handles unnamed repositories. (#333)

* renv gains the config option `hydrate.libpaths`, allowing one to control
  the library paths used by default for `renv::hydrate()`. (#329)

* `renv::hydrate()` gains the `sources` argument, used to control the library
  paths used by renv when hydrating a project. (#329)

* renv now sandboxes the system library by default on Windows.

* renv now validates that the Xcode license has been accepted before
  attempting to install R packages from sources. (#296)

* The R option `renv.download.override` can now be used to override the
  machinery used by renv when downloading files. For example, setting
  `options(renv.download.override = utils::download.file)` would instruct
  renv to use R's own downloader when downloading files from the internet.
  This can be useful when configuration of `curl` is challenging or
  intractable in your environment, or you've already configured the base
  R downloader suitably.

* `renv::use_python("~/path/to/python")` now works as expected.

* renv now properly expands `R_LIBS_SITE` and `R_LIBS_USER` when set within a
  startup `.Renviron` file. (#318)

* The `renv.download.headers` option can now be used to provide arbitrary HTTP
  headers when downloading files. See the **Authentication** section in
  `vignette("renv")` for more details. (#307)

* renv gains the project setting `package.dependency.fields`, for controlling
  which fields in an R package's `DESCRIPTION` file are examined when
  discovering recursive package dependencies. This can be useful when you'd like
  to instruct renv to track, for example, the `Suggests` dependencies of the
  packages used in your project. (#315)

* renv now better handles repositories referenced using file URIs.

* Packages installed from GitHub using `renv::install()` will now also have
  `Github*` fields added, in addition to the default `Remote*` fields. This
  should help fix issues when attempting to deploy projects to Posit Connect
  requiring packages installed by renv. (#397)

* renv now prefers using a RemoteType field (if any) when attempting to
  determine a package's source. (#306)

* renv gains a new function `renv::scaffold()`, for generating renv project
  infrastructure without explicitly loading the project. (#303)

* renv now updates its local `.gitignore` file, when part of a git repository
  whose git root lives in a parent directory. (#300)


# renv 0.9.2

* Fixed an issue in invoking `find` on Solaris.


# renv 0.9.1

* Fixed an issue in invoking `cp` on Solaris.


# renv 0.9.0

* renv gains a new function `renv::record()`, for recording new packages
  within an existing lockfile. This can be useful when one or more of the
  recorded packages need to be modified for some reason.

* An empty `.renvignore` no longer erroneously ignores all files within a
  directory. (#286)

* renv now warns if the version of renv loaded within a project does not
  match the version declared within the renv autoloader. (#285)

* renv gains a new function `renv::run()`, for running R scripts within
  a particular project's context inside an R subprocess. (#126)

* The algorithm used by renv for hashing packages has changed. Consider
  using `renv::rehash()` to migrate packages from the old renv cache to
  the new renv cache.

* `renv::status()` now reports packages which are referenced in your project
  code, but are not currently installed. (#271)

* renv is now able to restore packages with a recorded URL remote. (#272)

* `renv::dependencies()` can now parse R package dependencies used as custom
  site generator in an Rmd yaml header. (#269, @cderv)

* renv now properly respects a downloader requested by the environment
  variable `RENV_DOWNLOAD_FILE_METHOD`.

* renv no longer sources the user profile (normally located at `~/.Rprofile`)
  by default. If you desire this behavior, you can opt-in by setting
  `RENV_CONFIG_USER_PROFILE = TRUE`; e.g. within your project or user
  `.Renviron` file. (#261)

* `renv::restore()` gains the `packages` argument, to be used to restore
  a subset of packages recorded within the lockfile. (#260)

* renv now tries harder to preserve the existing structure in infrastructure
  files (e.g. the project `.Rprofile`) that it modifies. (#259)

* renv now warns if any Bioconductor packages used in the project appear
  to be from a different Bioconductor release than the one currently active
  and stored in the lockfile. (#244)

* renv now normalizes any paths set in the `RENV_PATHS_*` family of
  environment variables when renv is loaded.

* Fixed an issue where renv would not properly clean up after a failed
  attempt to call `Sys.junction()`. (#251)

* Fixed an issue where renv would, in some cases, copy rather than link from
  the package cache when the library path had been customized with the
  `RENV_PATHS_LIBRARY` environment variable. (#245)

* The method renv uses when copying directories can now be customized. When
  copying directories, renv now by default uses `robocopy` on Windows, and
  `cp` on Unix. This should improve robustness when attempting to copy files
  in some contexts; e.g. when copying across network shares.

* renv now tracks the version of Bioconductor used within a project
  (if applicable), and uses that when retrieving the set of repositories
  to be used during `renv::restore()`.

* `renv::dependencies()` can now parse R package dependencies declared and
  used by the `modules` package. (#238, @labriola)

* Fixed an issue where `renv::restore()` could fail in Docker environments,
  usually with an error message like 'Invalid cross-device link'. (#243)

* `renv::install()` disables staged package install when running with the
  Windows Subsystem for Linux. (#239)


# renv 0.8.3

* `renv::dependencies()` gains a new argument `dev`, indicating whether
  development dependencies should also be included in the set of discovered
  package dependencies. By default, only runtime dependencies will be reported.

* renv has gained the function `renv::diagnostics()`, which can occasionally
  be useful in understanding and diagnosing renv (mis)behaviors.

* `renv::equip()` can now be used on macOS to install the R LLVM toolchain
  normally used when compiling packages from source. renv will also use
  this toolchain as appropriate when building packages from source.

* `renv::install()` now provides a custom Makevars when building packages on
  macOS with Apple Clang, to avoid issues due to the use of '-fopenmp' during
  compilation.

* `renv::install()` now respects explicit version requests when discovered
  in a project's DESCRIPTION file. (#233)

* Fixed an issue where `renv:::actions()` would fail to report any actions if
  the project lockfile was empty. (#232)

* When using renv for R package development, renv will no longer attempt to
  write the package being developed to the lockfile. (#231)

* Fixes for checks run on CRAN.

* renv will now search for Rtools in more locations. (#225)

* `renv::load()` now ensures that the version of renv associated with
  the loaded project is loaded when possible. In addition, experimental
  support for switching between projects with `renv::load()` has been
  implemented. (#229)

* `renv::dependencies()` no longer treats folders named with the extension
  `.Rmd` as though they were regular files. (#228)

* It is now possible to install source packages contained within `.zip`
  archives using `renv::install()`.

* Fixed an issue where attempts to call `renv::restore()` with the path to the
  lockfile explicitly provided would fail. (#227)


# renv 0.8.2

* Further fixes for checks run on CRAN.


# renv 0.8.1

* Fixes for checks run on CRAN.


# renv 0.8.0

* Initial CRAN release.
